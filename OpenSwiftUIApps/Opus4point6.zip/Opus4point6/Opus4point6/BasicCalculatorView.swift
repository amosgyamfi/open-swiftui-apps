//
//  BasicCalculatorView.swift
//  Opus4point6
//
//  Standard 4-function calculator with Apple-style design.
//

import SwiftUI

// MARK: - View Model

@Observable
class BasicCalculatorViewModel {
    var display: String = "0"

    private var accumulator: Double = 0
    private var pendingOperation: Operation? = nil
    private var isEnteringNumber = false
    private var justPressedEquals = false
    private var lastOperand: Double = 0
    private var lastOperation: Operation? = nil

    enum Operation: Equatable {
        case add, subtract, multiply, divide

        func perform(_ a: Double, _ b: Double) -> Double {
            switch self {
            case .add: return a + b
            case .subtract: return a - b
            case .multiply: return a * b
            case .divide: return b == 0 ? .nan : a / b
            }
        }
    }

    var activeOperation: Operation? {
        if !isEnteringNumber && !justPressedEquals {
            return pendingOperation
        }
        return nil
    }

    var clearLabel: String {
        isEnteringNumber ? "C" : "AC"
    }

    func digitPressed(_ digit: String) {
        if display == "Error" {
            clearAll()
        }

        if justPressedEquals {
            clearAll()
            justPressedEquals = false
        }

        if !isEnteringNumber {
            display = digit == "." ? "0." : digit
            isEnteringNumber = true
        } else {
            if digit == "." {
                if display.contains(".") { return }
                display += "."
            } else {
                if display == "0" {
                    display = digit
                } else if display.count < 15 {
                    display += digit
                }
            }
        }
    }

    func operationPressed(_ op: Operation) {
        justPressedEquals = false

        if isEnteringNumber && pendingOperation != nil {
            let currentValue = Double(display) ?? 0
            let result = pendingOperation!.perform(accumulator, currentValue)
            accumulator = result
            display = formatNumber(result)
        } else {
            accumulator = Double(display) ?? 0
        }

        pendingOperation = op
        isEnteringNumber = false
    }

    func equalsPressed() {
        if justPressedEquals, let op = lastOperation {
            let currentValue = Double(display) ?? 0
            let result = op.perform(currentValue, lastOperand)
            display = formatNumber(result)
            accumulator = Double(display) ?? 0
            return
        }

        guard let op = pendingOperation else { return }

        let currentValue = Double(display) ?? 0
        lastOperand = currentValue
        lastOperation = op

        let result = op.perform(accumulator, currentValue)
        display = formatNumber(result)
        accumulator = Double(display) ?? 0
        pendingOperation = nil
        isEnteringNumber = false
        justPressedEquals = true
    }

    func clearPressed() {
        if isEnteringNumber {
            display = "0"
            isEnteringNumber = false
        } else {
            clearAll()
        }
    }

    func toggleSign() {
        if display == "0" || display == "Error" { return }
        if display.hasPrefix("-") {
            display = String(display.dropFirst())
        } else {
            display = "-" + display
        }
    }

    func percentage() {
        guard let value = Double(display) else { return }
        let result: Double
        if pendingOperation != nil {
            result = accumulator * value / 100.0
        } else {
            result = value / 100.0
        }
        display = formatNumber(result)
        isEnteringNumber = false
    }

    private func clearAll() {
        display = "0"
        accumulator = 0
        pendingOperation = nil
        isEnteringNumber = false
        justPressedEquals = false
        lastOperand = 0
        lastOperation = nil
    }

    func formatNumber(_ number: Double) -> String {
        if number.isNaN || number.isInfinite { return "Error" }
        if number == 0 { return "0" }

        if number == floor(number) && abs(number) < 1e15 {
            return String(format: "%.0f", number)
        }

        let formatter = NumberFormatter()
        formatter.maximumSignificantDigits = 10
        formatter.minimumSignificantDigits = 1
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = false

        return formatter.string(from: NSNumber(value: number)) ?? String(format: "%.10g", number)
    }
}

// MARK: - View

struct BasicCalculatorView: View {
    @State private var viewModel = BasicCalculatorViewModel()

    private let buttonSpacing: CGFloat = 12

    var body: some View {
        GeometryReader { geometry in
            let buttonWidth = (geometry.size.width - buttonSpacing * 5) / 4
            let buttonHeight = buttonWidth

            VStack(spacing: 0) {
                Spacer()

                // Display
                HStack {
                    Spacer()
                    Text(viewModel.display)
                        .font(.system(size: displayFontSize(for: viewModel.display), weight: .light))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.4)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 20)

                // Button Grid
                VStack(spacing: buttonSpacing) {
                    row1(buttonWidth: buttonWidth, buttonHeight: buttonHeight)
                    row2(buttonWidth: buttonWidth, buttonHeight: buttonHeight)
                    row3(buttonWidth: buttonWidth, buttonHeight: buttonHeight)
                    row4(buttonWidth: buttonWidth, buttonHeight: buttonHeight)
                    row5(buttonWidth: buttonWidth, buttonHeight: buttonHeight)
                }
                .padding(.horizontal, buttonSpacing)
                .padding(.bottom, buttonSpacing + 8)
            }
        }
    }

    // MARK: - Button Rows

    private func row1(buttonWidth: CGFloat, buttonHeight: CGFloat) -> some View {
        HStack(spacing: buttonSpacing) {
            calcButton(viewModel.clearLabel, style: .function, w: buttonWidth, h: buttonHeight) {
                viewModel.clearPressed()
            }
            calcButton("+/−", style: .function, w: buttonWidth, h: buttonHeight) {
                viewModel.toggleSign()
            }
            calcButton("%", style: .function, w: buttonWidth, h: buttonHeight) {
                viewModel.percentage()
            }
            calcButton("÷", style: .operation, w: buttonWidth, h: buttonHeight,
                        active: viewModel.activeOperation == .divide) {
                viewModel.operationPressed(.divide)
            }
        }
    }

    private func row2(buttonWidth: CGFloat, buttonHeight: CGFloat) -> some View {
        HStack(spacing: buttonSpacing) {
            calcButton("7", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("7") }
            calcButton("8", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("8") }
            calcButton("9", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("9") }
            calcButton("×", style: .operation, w: buttonWidth, h: buttonHeight,
                        active: viewModel.activeOperation == .multiply) {
                viewModel.operationPressed(.multiply)
            }
        }
    }

    private func row3(buttonWidth: CGFloat, buttonHeight: CGFloat) -> some View {
        HStack(spacing: buttonSpacing) {
            calcButton("4", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("4") }
            calcButton("5", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("5") }
            calcButton("6", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("6") }
            calcButton("−", style: .operation, w: buttonWidth, h: buttonHeight,
                        active: viewModel.activeOperation == .subtract) {
                viewModel.operationPressed(.subtract)
            }
        }
    }

    private func row4(buttonWidth: CGFloat, buttonHeight: CGFloat) -> some View {
        HStack(spacing: buttonSpacing) {
            calcButton("1", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("1") }
            calcButton("2", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("2") }
            calcButton("3", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed("3") }
            calcButton("+", style: .operation, w: buttonWidth, h: buttonHeight,
                        active: viewModel.activeOperation == .add) {
                viewModel.operationPressed(.add)
            }
        }
    }

    private func row5(buttonWidth: CGFloat, buttonHeight: CGFloat) -> some View {
        HStack(spacing: buttonSpacing) {
            wideButton("0", w: buttonWidth * 2 + buttonSpacing, h: buttonHeight) {
                viewModel.digitPressed("0")
            }
            calcButton(".", w: buttonWidth, h: buttonHeight) { viewModel.digitPressed(".") }
            calcButton("=", style: .operation, w: buttonWidth, h: buttonHeight) {
                viewModel.equalsPressed()
            }
        }
    }

    // MARK: - Display Font Size

    private func displayFontSize(for text: String) -> CGFloat {
        let count = text.count
        if count <= 6 { return 80 }
        if count <= 9 { return 64 }
        if count <= 12 { return 48 }
        return 36
    }

    // MARK: - Button Styles

    enum ButtonStyle {
        case number, operation, function
    }

    private func calcButton(
        _ title: String,
        style: ButtonStyle = .number,
        w: CGFloat,
        h: CGFloat,
        active: Bool = false,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: style == .function ? 22 : 30, weight: style == .function ? .medium : .regular))
                .frame(width: w, height: h)
                .background(buttonBG(style: style, active: active))
                .foregroundStyle(buttonFG(style: style, active: active))
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    private func wideButton(
        _ title: String,
        w: CGFloat,
        h: CGFloat,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(.system(size: 30))
                    .padding(.leading, h * 0.37)
                Spacer()
            }
            .frame(width: w, height: h)
            .background(Color(white: 0.2))
            .foregroundStyle(.white)
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    private func buttonBG(style: ButtonStyle, active: Bool) -> Color {
        if active { return .white }
        switch style {
        case .number: return Color(white: 0.2)
        case .operation: return .orange
        case .function: return Color(white: 0.65)
        }
    }

    private func buttonFG(style: ButtonStyle, active: Bool) -> Color {
        if active { return .orange }
        return style == .function ? .black : .white
    }
}
