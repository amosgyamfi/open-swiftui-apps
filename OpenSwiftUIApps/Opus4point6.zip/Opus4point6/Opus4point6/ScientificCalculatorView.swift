//
//  ScientificCalculatorView.swift
//  Opus4point6
//
//  Expression-based scientific calculator with trig, log, powers, memory, and parentheses.
//

import SwiftUI

// MARK: - View Model

@Observable
class ScientificCalculatorViewModel {
    var expression: String = ""
    var displayResult: String = "0"
    var useDegrees: Bool = true
    var isSecondFunction: Bool = false
    var memory: Double = 0
    var hasMemory: Bool = false

    private let parser = ExpressionParser()
    private var justEvaluated = false
    private var lastResult: String = "0"

    // MARK: - Input Methods

    func digitPressed(_ digit: String) {
        if justEvaluated {
            expression = digit
            justEvaluated = false
        } else {
            expression += digit
        }
        evaluateLive()
    }

    func operatorPressed(_ op: String) {
        if justEvaluated {
            expression = lastResult + op
            justEvaluated = false
        } else {
            expression += op
        }
        evaluateLive()
    }

    func functionPressed(_ fn: String) {
        if justEvaluated {
            expression = fn + "(" + lastResult
            justEvaluated = false
        } else {
            // Add implicit × if previous token is a number, ), or !
            if let last = expression.last,
               last.isNumber || last == ")" || last == "!" || last == "π" {
                expression += "×" + fn + "("
            } else {
                expression += fn + "("
            }
        }
    }

    func constantPressed(_ symbol: String) {
        if justEvaluated {
            expression = symbol
            justEvaluated = false
        } else if let last = expression.last,
                  last.isNumber || last == ")" || last == "!" || last == "π" {
            expression += "×" + symbol
        } else {
            expression += symbol
        }
        evaluateLive()
    }

    func powerPressed(_ power: String) {
        if justEvaluated {
            expression = lastResult + power
            justEvaluated = false
        } else {
            expression += power
        }
        evaluateLive()
    }

    func factorialPressed() {
        if justEvaluated {
            expression = lastResult + "!"
            justEvaluated = false
        } else {
            expression += "!"
        }
        evaluateLive()
    }

    func openParen() {
        if justEvaluated {
            expression = "("
            justEvaluated = false
        } else if let last = expression.last,
                  last.isNumber || last == ")" || last == "π" {
            expression += "×("
        } else {
            expression += "("
        }
    }

    func closeParen() {
        expression += ")"
        evaluateLive()
    }

    func reciprocal() {
        if justEvaluated {
            expression = "1/(" + lastResult + ")"
            justEvaluated = false
        } else if !expression.isEmpty {
            expression = "1/(" + expression + ")"
        }
        evaluateLive()
    }

    func equalsPressed() {
        // Auto-close parentheses
        let openCount = expression.filter { $0 == "(" }.count
        let closeCount = expression.filter { $0 == ")" }.count
        let missing = openCount - closeCount
        if missing > 0 {
            expression += String(repeating: ")", count: missing)
        }

        parser.useDegrees = useDegrees

        if let result = try? parser.evaluate(expression) {
            let formatted = formatNumber(result)
            displayResult = formatted
            lastResult = formatted
            justEvaluated = true
        } else {
            displayResult = "Error"
            justEvaluated = true
            lastResult = "0"
        }
    }

    func clearPressed() {
        expression = ""
        displayResult = "0"
        justEvaluated = false
    }

    func deletePressed() {
        if justEvaluated {
            return
        }
        if !expression.isEmpty {
            expression.removeLast()
            evaluateLive()
        }
    }

    func eePressed() {
        if justEvaluated {
            expression = lastResult + "e"
            justEvaluated = false
        } else {
            expression += "e"
        }
    }

    func randomPressed() {
        let rand = Double.random(in: 0..<1)
        let formatted = formatNumber(rand)
        if justEvaluated {
            expression = formatted
            justEvaluated = false
        } else {
            expression += formatted
        }
        evaluateLive()
    }

    // MARK: - Memory

    func memoryClear() {
        memory = 0
        hasMemory = false
    }

    func memoryRecall() {
        let formatted = formatNumber(memory)
        if justEvaluated {
            expression = formatted
            justEvaluated = false
        } else {
            expression += formatted
        }
        evaluateLive()
    }

    func memoryAdd() {
        if let value = Double(displayResult) {
            memory += value
            hasMemory = true
        }
    }

    func memorySubtract() {
        if let value = Double(displayResult) {
            memory -= value
            hasMemory = true
        }
    }

    // MARK: - Helpers

    private func evaluateLive() {
        guard !expression.isEmpty else {
            displayResult = "0"
            return
        }

        parser.useDegrees = useDegrees

        // Try evaluating with auto-closed parens
        var expr = expression
        let openCount = expr.filter { $0 == "(" }.count
        let closeCount = expr.filter { $0 == ")" }.count
        let missing = openCount - closeCount
        if missing > 0 {
            expr += String(repeating: ")", count: missing)
        }

        if let result = try? parser.evaluate(expr) {
            displayResult = formatNumber(result)
        }
    }

    private func formatNumber(_ number: Double) -> String {
        if number.isNaN || number.isInfinite { return "Error" }
        if number == 0 { return "0" }

        if number == floor(number) && abs(number) < 1e15 {
            return String(format: "%.0f", number)
        }

        let formatter = NumberFormatter()
        formatter.maximumSignificantDigits = 10
        formatter.minimumSignificantDigits = 1
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = false
        return formatter.string(from: NSNumber(value: number)) ?? String(format: "%.10g", number)
    }
}

// MARK: - View

struct ScientificCalculatorView: View {
    @State private var vm = ScientificCalculatorViewModel()

    private let sciSpacing: CGFloat = 5
    private let keySpacing: CGFloat = 12

    var body: some View {
        GeometryReader { geo in
            let keyW = (geo.size.width - keySpacing * 5) / 4
            let keyH = keyW * 0.82
            let sciW = (geo.size.width - sciSpacing * 7) / 6
            let sciH: CGFloat = 38

            VStack(spacing: 0) {
                Spacer(minLength: 4)

                // Expression display
                expressionDisplay

                // Result display
                resultDisplay

                // Scientific function buttons
                scientificGrid(w: sciW, h: sciH)
                    .padding(.bottom, 8)

                // Standard keypad
                standardKeypad(w: keyW, h: keyH)
                    .padding(.bottom, keySpacing + 4)
            }
            .padding(.horizontal, keySpacing)
        }
    }

    // MARK: - Displays

    private var expressionDisplay: some View {
        HStack {
            Spacer()
            Text(vm.expression.isEmpty ? " " : vm.expression)
                .font(.system(size: 22, weight: .regular, design: .monospaced))
                .foregroundStyle(.gray)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
        }
        .padding(.horizontal, 12)
        .padding(.bottom, 4)
    }

    private var resultDisplay: some View {
        HStack {
            Spacer()
            Text(vm.displayResult)
                .font(.system(size: resultFontSize, weight: .light))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.4)
        }
        .padding(.horizontal, 12)
        .padding(.bottom, 12)
    }

    private var resultFontSize: CGFloat {
        let count = vm.displayResult.count
        if count <= 8 { return 56 }
        if count <= 12 { return 44 }
        return 32
    }

    // MARK: - Scientific Grid

    private func scientificGrid(w: CGFloat, h: CGFloat) -> some View {
        VStack(spacing: sciSpacing) {
            // Row 1: Rad/Deg, 2nd, x², x³, xʸ, eˣ
            HStack(spacing: sciSpacing) {
                sciButton(vm.useDegrees ? "Deg" : "Rad", w: w, h: h, highlight: true) {
                    vm.useDegrees.toggle()
                }
                sciButton("2nd", w: w, h: h, highlight: vm.isSecondFunction) {
                    vm.isSecondFunction.toggle()
                }
                sciButton("x²", w: w, h: h) { vm.powerPressed("^2") }
                sciButton("x³", w: w, h: h) { vm.powerPressed("^3") }
                sciButton("xʸ", w: w, h: h) { vm.powerPressed("^") }
                sciButton("eˣ", w: w, h: h) { vm.functionPressed("exp") }
            }
            // Row 2: 1/x, √x, ∛x, ln, log, 10ˣ
            HStack(spacing: sciSpacing) {
                sciButton("1/x", w: w, h: h) { vm.reciprocal() }
                sciButton("√x", w: w, h: h) { vm.functionPressed("sqrt") }
                sciButton("∛x", w: w, h: h) { vm.functionPressed("cbrt") }
                sciButton("ln", w: w, h: h) { vm.functionPressed("ln") }
                sciButton("log", w: w, h: h) { vm.functionPressed("log") }
                sciButton("10ˣ", w: w, h: h) { vm.powerPressed("10^") }
            }
            // Row 3: x!, sin/asin, cos/acos, tan/atan, e, π
            HStack(spacing: sciSpacing) {
                sciButton("x!", w: w, h: h) { vm.factorialPressed() }
                sciButton(vm.isSecondFunction ? "sin⁻¹" : "sin", w: w, h: h) {
                    vm.functionPressed(vm.isSecondFunction ? "asin" : "sin")
                }
                sciButton(vm.isSecondFunction ? "cos⁻¹" : "cos", w: w, h: h) {
                    vm.functionPressed(vm.isSecondFunction ? "acos" : "cos")
                }
                sciButton(vm.isSecondFunction ? "tan⁻¹" : "tan", w: w, h: h) {
                    vm.functionPressed(vm.isSecondFunction ? "atan" : "tan")
                }
                sciButton("e", w: w, h: h) { vm.constantPressed("e") }
                sciButton("π", w: w, h: h) { vm.constantPressed("π") }
            }
            // Row 4: (, ), MC, M+, M-, MR
            HStack(spacing: sciSpacing) {
                sciButton("(", w: w, h: h) { vm.openParen() }
                sciButton(")", w: w, h: h) { vm.closeParen() }
                sciButton("mc", w: w, h: h, dimmed: !vm.hasMemory) { vm.memoryClear() }
                sciButton("m+", w: w, h: h) { vm.memoryAdd() }
                sciButton("m−", w: w, h: h) { vm.memorySubtract() }
                sciButton("mr", w: w, h: h, dimmed: !vm.hasMemory) { vm.memoryRecall() }
            }
        }
    }

    // MARK: - Standard Keypad

    private func standardKeypad(w: CGFloat, h: CGFloat) -> some View {
        VStack(spacing: keySpacing) {
            // Row 1: AC, ⌫, %, ÷
            HStack(spacing: keySpacing) {
                keyButton("AC", style: .function, w: w, h: h) { vm.clearPressed() }
                keyButton("⌫", style: .function, w: w, h: h, isSymbol: true) { vm.deletePressed() }
                keyButton("%", style: .function, w: w, h: h) { vm.operatorPressed("%") }
                keyButton("÷", style: .operation, w: w, h: h) { vm.operatorPressed("÷") }
            }
            // Row 2: 7 8 9 ×
            HStack(spacing: keySpacing) {
                keyButton("7", w: w, h: h) { vm.digitPressed("7") }
                keyButton("8", w: w, h: h) { vm.digitPressed("8") }
                keyButton("9", w: w, h: h) { vm.digitPressed("9") }
                keyButton("×", style: .operation, w: w, h: h) { vm.operatorPressed("×") }
            }
            // Row 3: 4 5 6 −
            HStack(spacing: keySpacing) {
                keyButton("4", w: w, h: h) { vm.digitPressed("4") }
                keyButton("5", w: w, h: h) { vm.digitPressed("5") }
                keyButton("6", w: w, h: h) { vm.digitPressed("6") }
                keyButton("−", style: .operation, w: w, h: h) { vm.operatorPressed("−") }
            }
            // Row 4: 1 2 3 +
            HStack(spacing: keySpacing) {
                keyButton("1", w: w, h: h) { vm.digitPressed("1") }
                keyButton("2", w: w, h: h) { vm.digitPressed("2") }
                keyButton("3", w: w, h: h) { vm.digitPressed("3") }
                keyButton("+", style: .operation, w: w, h: h) { vm.operatorPressed("+") }
            }
            // Row 5: 0 (wide), ., =
            HStack(spacing: keySpacing) {
                Button(action: { vm.digitPressed("0") }) {
                    HStack {
                        Text("0")
                            .font(.system(size: 26))
                            .padding(.leading, h * 0.37)
                        Spacer()
                    }
                    .frame(width: w * 2 + keySpacing, height: h)
                    .background(Color(white: 0.2))
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
                }
                .buttonStyle(.plain)

                keyButton(".", w: w, h: h) { vm.digitPressed(".") }
                keyButton("=", style: .operation, w: w, h: h) { vm.equalsPressed() }
            }
        }
    }

    // MARK: - Button Builders

    private func sciButton(
        _ title: String,
        w: CGFloat,
        h: CGFloat,
        highlight: Bool = false,
        dimmed: Bool = false,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: h)
                .background(highlight ? Color.orange.opacity(0.3) : Color(white: 0.12))
                .foregroundStyle(dimmed ? .gray.opacity(0.5) : (highlight ? .orange : .white))
                .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
    }

    enum KeyStyle { case number, operation, function }

    private func keyButton(
        _ title: String,
        style: KeyStyle = .number,
        w: CGFloat,
        h: CGFloat,
        isSymbol: Bool = false,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Group {
                if isSymbol {
                    Image(systemName: "delete.left")
                        .font(.system(size: 20, weight: .medium))
                } else {
                    Text(title)
                        .font(.system(size: style == .function ? 20 : 26,
                                      weight: style == .function ? .medium : .regular))
                }
            }
            .frame(width: w, height: h)
            .background(keyBG(style))
            .foregroundStyle(keyFG(style))
            .clipShape(RoundedRectangle(cornerRadius: w * 0.36))
        }
        .buttonStyle(.plain)
    }

    private func keyBG(_ style: KeyStyle) -> Color {
        switch style {
        case .number: return Color(white: 0.2)
        case .operation: return .orange
        case .function: return Color(white: 0.65)
        }
    }

    private func keyFG(_ style: KeyStyle) -> Color {
        style == .function ? .black : .white
    }
}
