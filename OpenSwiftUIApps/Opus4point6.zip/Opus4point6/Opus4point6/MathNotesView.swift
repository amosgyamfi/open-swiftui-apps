//
//  MathNotesView.swift
//  Opus4point6
//
//  Notebook-style math environment with live evaluation,
//  variable storage, and function graphing.
//

import SwiftUI

// MARK: - Models

struct MathNoteLine: Identifiable {
    let id = UUID()
    var input: String = ""
    var result: String?
    var isGraphable: Bool = false
    var showGraph: Bool = false
    var variableName: String? = nil
}

// MARK: - View Model

@Observable
class MathNotesViewModel {
    var lines: [MathNoteLine] = [MathNoteLine()]
    var variables: [String: Double] = [:]

    private let parser = ExpressionParser()

    func evaluateLine(at index: Int) {
        guard index < lines.count else { return }
        let input = lines[index].input.trimmingCharacters(in: .whitespaces)

        guard !input.isEmpty else {
            lines[index].result = nil
            lines[index].isGraphable = false
            lines[index].variableName = nil
            return
        }

        // Check for variable assignment: "name = expression"
        if let eqRange = input.range(of: "="),
           !input.hasPrefix("="),
           !input.contains("==") {
            let lhs = String(input[input.startIndex..<eqRange.lowerBound]).trimmingCharacters(in: .whitespaces)
            let rhs = String(input[eqRange.upperBound...]).trimmingCharacters(in: .whitespaces)

            // Validate LHS is a simple identifier
            let isValidName = !lhs.isEmpty && lhs.allSatisfy { $0.isLetter || $0.isNumber || $0 == "_" }
                && (lhs.first?.isLetter ?? false)
                && lhs != "e" && lhs != "pi"

            if isValidName && !rhs.isEmpty {
                parser.variables = variables
                if let value = try? parser.evaluate(rhs) {
                    variables[lhs] = value
                    parser.variables = variables
                    lines[index].result = formatResult(value)
                    lines[index].variableName = lhs
                    lines[index].isGraphable = rhs.contains("x")
                    return
                }
            }
        }

        // Check for graph command: "graph expression"
        if input.lowercased().hasPrefix("graph ") {
            let expr = String(input.dropFirst(6)).trimmingCharacters(in: .whitespaces)
            lines[index].isGraphable = true
            lines[index].showGraph = true

            parser.variables = variables
            parser.variables["x"] = 0
            if let value = try? parser.evaluate(expr) {
                lines[index].result = "f(0) = \(formatResult(value))"
            } else {
                lines[index].result = nil
            }
            return
        }

        // Regular expression evaluation
        parser.variables = variables
        lines[index].isGraphable = input.contains("x") && !input.contains("exp")
        lines[index].variableName = nil

        if let value = try? parser.evaluate(input) {
            lines[index].result = formatResult(value)
        } else {
            lines[index].result = input.isEmpty ? nil : "?"
        }
    }

    func addLine() {
        lines.append(MathNoteLine())
    }

    func removeLine(at index: Int) {
        guard lines.count > 1 else { return }
        let removed = lines.remove(at: index)
        // Remove variable if this line defined one
        if let name = removed.variableName {
            variables.removeValue(forKey: name)
        }
        // Re-evaluate all lines since variables may have changed
        reEvaluateAll()
    }

    func clearAll() {
        lines = [MathNoteLine()]
        variables = [:]
    }

    func reEvaluateAll() {
        variables = [:]
        for i in 0..<lines.count {
            evaluateLine(at: i)
        }
    }

    func getGraphExpression(for line: MathNoteLine) -> String {
        let input = line.input.trimmingCharacters(in: .whitespaces)
        if input.lowercased().hasPrefix("graph ") {
            return String(input.dropFirst(6)).trimmingCharacters(in: .whitespaces)
        }
        if let eqRange = input.range(of: "="),
           !input.hasPrefix("=") {
            return String(input[eqRange.upperBound...]).trimmingCharacters(in: .whitespaces)
        }
        return input
    }

    private func formatResult(_ number: Double) -> String {
        if number.isNaN || number.isInfinite { return "Error" }
        if number == 0 { return "0" }
        if number == floor(number) && abs(number) < 1e12 {
            return String(format: "%.0f", number)
        }
        let formatter = NumberFormatter()
        formatter.maximumSignificantDigits = 8
        formatter.minimumSignificantDigits = 1
        formatter.numberStyle = .decimal
        formatter.usesGroupingSeparator = true
        return formatter.string(from: NSNumber(value: number)) ?? String(format: "%.8g", number)
    }
}

// MARK: - Graph View

struct FunctionGraphView: View {
    let expression: String
    let variables: [String: Double]

    @State private var xMin: Double = -10
    @State private var xMax: Double = 10

    var body: some View {
        VStack(spacing: 4) {
            Canvas { context, size in
                drawGraph(context: context, size: size)
            }
            .frame(height: 200)
            .background(Color(white: 0.08))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color(white: 0.2), lineWidth: 1)
            )

            // Zoom controls
            HStack {
                Button(action: zoomIn) {
                    Image(systemName: "plus.magnifyingglass")
                        .font(.system(size: 14))
                }
                Spacer()
                Text("x: [\(Int(xMin)), \(Int(xMax))]")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(.secondary)
                Spacer()
                Button(action: zoomOut) {
                    Image(systemName: "minus.magnifyingglass")
                        .font(.system(size: 14))
                }
            }
            .foregroundStyle(.secondary)
            .padding(.horizontal, 8)
        }
    }

    private func drawGraph(context: GraphicsContext, size: CGSize) {
        let w = size.width
        let h = size.height
        let parser = ExpressionParser()
        parser.variables = variables
        let steps = Int(w)

        // Compute y values
        var points: [(x: Double, y: Double)] = []
        for i in 0...steps {
            let x = xMin + (xMax - xMin) * Double(i) / Double(steps)
            parser.variables["x"] = x
            if let y = try? parser.evaluate(expression), y.isFinite {
                points.append((x: x, y: y))
            }
        }

        guard !points.isEmpty else { return }

        let yValues = points.map(\.y)
        var yMinVal = yValues.min() ?? -1
        var yMaxVal = yValues.max() ?? 1
        if yMinVal == yMaxVal {
            yMinVal -= 1
            yMaxVal += 1
        }
        let yPad = (yMaxVal - yMinVal) * 0.1
        yMinVal -= yPad
        yMaxVal += yPad
        let yRange = yMaxVal - yMinVal

        // Grid lines
        let gridColor = Color(white: 0.2)

        // Draw axes
        let xAxisY = h * CGFloat((yMaxVal - 0) / yRange)
        if xAxisY >= 0 && xAxisY <= h {
            var axisPath = Path()
            axisPath.move(to: CGPoint(x: 0, y: xAxisY))
            axisPath.addLine(to: CGPoint(x: w, y: xAxisY))
            context.stroke(axisPath, with: .color(gridColor), lineWidth: 1)
        }

        let yAxisX = w * CGFloat((0 - xMin) / (xMax - xMin))
        if yAxisX >= 0 && yAxisX <= w {
            var axisPath = Path()
            axisPath.move(to: CGPoint(x: yAxisX, y: 0))
            axisPath.addLine(to: CGPoint(x: yAxisX, y: h))
            context.stroke(axisPath, with: .color(gridColor), lineWidth: 1)
        }

        // Draw grid
        for tick in stride(from: ceil(xMin), through: floor(xMax), by: max(1, (xMax - xMin) / 10)) {
            let px = w * CGFloat((tick - xMin) / (xMax - xMin))
            var gridPath = Path()
            gridPath.move(to: CGPoint(x: px, y: 0))
            gridPath.addLine(to: CGPoint(x: px, y: h))
            context.stroke(gridPath, with: .color(Color(white: 0.12)), lineWidth: 0.5)
        }
        for tick in stride(from: ceil(yMinVal), through: floor(yMaxVal), by: max(1, yRange / 10)) {
            let py = h * CGFloat((yMaxVal - tick) / yRange)
            var gridPath = Path()
            gridPath.move(to: CGPoint(x: 0, y: py))
            gridPath.addLine(to: CGPoint(x: w, y: py))
            context.stroke(gridPath, with: .color(Color(white: 0.12)), lineWidth: 0.5)
        }

        // Draw curve
        var curvePath = Path()
        var started = false
        for point in points {
            let px = w * CGFloat((point.x - xMin) / (xMax - xMin))
            let py = h * CGFloat((yMaxVal - point.y) / yRange)

            if py < -h || py > h * 2 {
                started = false
                continue
            }

            if !started {
                curvePath.move(to: CGPoint(x: px, y: py))
                started = true
            } else {
                curvePath.addLine(to: CGPoint(x: px, y: py))
            }
        }

        context.stroke(curvePath, with: .color(.orange), style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
    }

    private func zoomIn() {
        let center = (xMin + xMax) / 2
        let range = (xMax - xMin) / 2
        let newRange = range * 0.5
        xMin = center - newRange
        xMax = center + newRange
    }

    private func zoomOut() {
        let center = (xMin + xMax) / 2
        let range = (xMax - xMin) / 2
        let newRange = range * 2
        xMin = center - newRange
        xMax = center + newRange
    }
}

// MARK: - Main View

struct MathNotesView: View {
    @State private var vm = MathNotesViewModel()
    @FocusState private var focusedLine: UUID?

    var body: some View {
        VStack(spacing: 0) {
            // Header
            header

            // Variables summary
            if !vm.variables.isEmpty {
                variablesSummary
            }

            // Notes
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(Array(vm.lines.enumerated()), id: \.element.id) { index, line in
                        noteLineView(index: index, line: line)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 100)
            }
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack {
            Text("Math Notes")
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(.white)

            Spacer()

            Button(action: { vm.addLine() }) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(.orange)
            }

            Button(action: { vm.clearAll() }) {
                Image(systemName: "trash.circle.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(.red.opacity(0.7))
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
    }

    // MARK: - Variables Summary

    private var variablesSummary: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(vm.variables.keys.sorted()), id: \.self) { key in
                    if let value = vm.variables[key] {
                        HStack(spacing: 4) {
                            Text(key)
                                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                                .foregroundStyle(.orange)
                            Text("=")
                                .font(.system(size: 11))
                                .foregroundStyle(.secondary)
                            Text(formatCompact(value))
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundStyle(.white)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color(white: 0.12))
                        .clipShape(Capsule())
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 8)
        }
    }

    // MARK: - Note Line

    private func noteLineView(index: Int, line: MathNoteLine) -> some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                // Line number
                Text("\(index + 1)")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(.secondary.opacity(0.5))
                    .frame(width: 28, alignment: .trailing)

                // Input field
                TextField("Enter expression...", text: Binding(
                    get: { vm.lines[safe: index]?.input ?? "" },
                    set: { newValue in
                        if index < vm.lines.count {
                            vm.lines[index].input = newValue
                            vm.evaluateLine(at: index)
                        }
                    }
                ))
                .font(.system(size: 17, design: .monospaced))
                .foregroundStyle(.white)
                .textFieldStyle(.plain)
                .focused($focusedLine, equals: line.id)
                .onSubmit {
                    if index == vm.lines.count - 1 {
                        vm.addLine()
                    }
                    // Focus next line
                    if index + 1 < vm.lines.count {
                        focusedLine = vm.lines[index + 1].id
                    }
                }

                Spacer()

                // Result
                if let result = line.result {
                    Text("= \(result)")
                        .font(.system(size: 17, weight: .medium, design: .monospaced))
                        .foregroundStyle(.orange)
                        .lineLimit(1)
                }

                // Graph toggle
                if line.isGraphable {
                    Button(action: {
                        vm.lines[index].showGraph.toggle()
                    }) {
                        Image(systemName: line.showGraph ? "chart.xyaxis.line" : "chart.xyaxis.line")
                            .font(.system(size: 14))
                            .foregroundStyle(line.showGraph ? .orange : .secondary)
                            .padding(.leading, 6)
                    }
                }

                // Delete button
                if vm.lines.count > 1 {
                    Button(action: { vm.removeLine(at: index) }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 14))
                            .foregroundStyle(.secondary.opacity(0.5))
                            .padding(.leading, 4)
                    }
                }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 10)

            // Divider
            Rectangle()
                .fill(Color(white: 0.15))
                .frame(height: 1)
                .padding(.leading, 36)

            // Graph
            if line.showGraph && line.isGraphable {
                let expr = vm.getGraphExpression(for: line)
                FunctionGraphView(expression: expr, variables: vm.variables)
                    .padding(.horizontal, 36)
                    .padding(.vertical, 8)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: line.showGraph)
    }

    private func formatCompact(_ value: Double) -> String {
        if value == floor(value) && abs(value) < 1e6 {
            return String(format: "%.0f", value)
        }
        return String(format: "%.4g", value)
    }
}

// MARK: - Safe Collection Access

extension Collection {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
