//
//  CurrencyConverterView.swift
//  Opus4point6
//
//  Multi-currency converter with all major world currencies.
//  Uses offline exchange rates (approximate, relative to USD).
//

import SwiftUI

// MARK: - Currency Model

struct CurrencyInfo: Identifiable, Hashable {
    let code: String
    let name: String
    let symbol: String
    let flag: String
    let rateToUSD: Double // 1 USD = rateToUSD units of this currency

    var id: String { code }
}

// MARK: - Currency Data

enum CurrencyData {
    static let all: [CurrencyInfo] = [
        // Americas
        CurrencyInfo(code: "USD", name: "US Dollar", symbol: "$", flag: "🇺🇸", rateToUSD: 1.0),
        CurrencyInfo(code: "CAD", name: "Canadian Dollar", symbol: "C$", flag: "🇨🇦", rateToUSD: 1.36),
        CurrencyInfo(code: "MXN", name: "Mexican Peso", symbol: "MX$", flag: "🇲🇽", rateToUSD: 17.15),
        CurrencyInfo(code: "BRL", name: "Brazilian Real", symbol: "R$", flag: "🇧🇷", rateToUSD: 4.97),
        CurrencyInfo(code: "ARS", name: "Argentine Peso", symbol: "AR$", flag: "🇦🇷", rateToUSD: 850.0),
        CurrencyInfo(code: "CLP", name: "Chilean Peso", symbol: "CL$", flag: "🇨🇱", rateToUSD: 890.0),
        CurrencyInfo(code: "COP", name: "Colombian Peso", symbol: "CO$", flag: "🇨🇴", rateToUSD: 3950.0),
        CurrencyInfo(code: "PEN", name: "Peruvian Sol", symbol: "S/.", flag: "🇵🇪", rateToUSD: 3.72),

        // Europe
        CurrencyInfo(code: "EUR", name: "Euro", symbol: "€", flag: "🇪🇺", rateToUSD: 0.92),
        CurrencyInfo(code: "GBP", name: "British Pound", symbol: "£", flag: "🇬🇧", rateToUSD: 0.79),
        CurrencyInfo(code: "CHF", name: "Swiss Franc", symbol: "CHF", flag: "🇨🇭", rateToUSD: 0.88),
        CurrencyInfo(code: "SEK", name: "Swedish Krona", symbol: "kr", flag: "🇸🇪", rateToUSD: 10.42),
        CurrencyInfo(code: "NOK", name: "Norwegian Krone", symbol: "kr", flag: "🇳🇴", rateToUSD: 10.55),
        CurrencyInfo(code: "DKK", name: "Danish Krone", symbol: "kr", flag: "🇩🇰", rateToUSD: 6.87),
        CurrencyInfo(code: "PLN", name: "Polish Zloty", symbol: "zł", flag: "🇵🇱", rateToUSD: 4.02),
        CurrencyInfo(code: "CZK", name: "Czech Koruna", symbol: "Kč", flag: "🇨🇿", rateToUSD: 22.85),
        CurrencyInfo(code: "HUF", name: "Hungarian Forint", symbol: "Ft", flag: "🇭🇺", rateToUSD: 355.0),
        CurrencyInfo(code: "RON", name: "Romanian Leu", symbol: "lei", flag: "🇷🇴", rateToUSD: 4.58),
        CurrencyInfo(code: "TRY", name: "Turkish Lira", symbol: "₺", flag: "🇹🇷", rateToUSD: 30.25),
        CurrencyInfo(code: "UAH", name: "Ukrainian Hryvnia", symbol: "₴", flag: "🇺🇦", rateToUSD: 37.50),
        CurrencyInfo(code: "RUB", name: "Russian Ruble", symbol: "₽", flag: "🇷🇺", rateToUSD: 92.0),
        CurrencyInfo(code: "ISK", name: "Icelandic Króna", symbol: "kr", flag: "🇮🇸", rateToUSD: 137.0),

        // Asia Pacific
        CurrencyInfo(code: "JPY", name: "Japanese Yen", symbol: "¥", flag: "🇯🇵", rateToUSD: 149.50),
        CurrencyInfo(code: "CNY", name: "Chinese Yuan", symbol: "¥", flag: "🇨🇳", rateToUSD: 7.24),
        CurrencyInfo(code: "HKD", name: "Hong Kong Dollar", symbol: "HK$", flag: "🇭🇰", rateToUSD: 7.82),
        CurrencyInfo(code: "TWD", name: "Taiwan Dollar", symbol: "NT$", flag: "🇹🇼", rateToUSD: 31.50),
        CurrencyInfo(code: "KRW", name: "South Korean Won", symbol: "₩", flag: "🇰🇷", rateToUSD: 1325.0),
        CurrencyInfo(code: "SGD", name: "Singapore Dollar", symbol: "S$", flag: "🇸🇬", rateToUSD: 1.34),
        CurrencyInfo(code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "🇦🇺", rateToUSD: 1.54),
        CurrencyInfo(code: "NZD", name: "New Zealand Dollar", symbol: "NZ$", flag: "🇳🇿", rateToUSD: 1.67),
        CurrencyInfo(code: "INR", name: "Indian Rupee", symbol: "₹", flag: "🇮🇳", rateToUSD: 83.12),
        CurrencyInfo(code: "PKR", name: "Pakistani Rupee", symbol: "₨", flag: "🇵🇰", rateToUSD: 282.0),
        CurrencyInfo(code: "BDT", name: "Bangladeshi Taka", symbol: "৳", flag: "🇧🇩", rateToUSD: 110.0),
        CurrencyInfo(code: "THB", name: "Thai Baht", symbol: "฿", flag: "🇹🇭", rateToUSD: 35.50),
        CurrencyInfo(code: "MYR", name: "Malaysian Ringgit", symbol: "RM", flag: "🇲🇾", rateToUSD: 4.72),
        CurrencyInfo(code: "IDR", name: "Indonesian Rupiah", symbol: "Rp", flag: "🇮🇩", rateToUSD: 15650.0),
        CurrencyInfo(code: "PHP", name: "Philippine Peso", symbol: "₱", flag: "🇵🇭", rateToUSD: 56.50),
        CurrencyInfo(code: "VND", name: "Vietnamese Dong", symbol: "₫", flag: "🇻🇳", rateToUSD: 24500.0),

        // Middle East
        CurrencyInfo(code: "AED", name: "UAE Dirham", symbol: "د.إ", flag: "🇦🇪", rateToUSD: 3.67),
        CurrencyInfo(code: "SAR", name: "Saudi Riyal", symbol: "﷼", flag: "🇸🇦", rateToUSD: 3.75),
        CurrencyInfo(code: "ILS", name: "Israeli Shekel", symbol: "₪", flag: "🇮🇱", rateToUSD: 3.65),
        CurrencyInfo(code: "QAR", name: "Qatari Riyal", symbol: "QR", flag: "🇶🇦", rateToUSD: 3.64),
        CurrencyInfo(code: "KWD", name: "Kuwaiti Dinar", symbol: "KD", flag: "🇰🇼", rateToUSD: 0.31),
        CurrencyInfo(code: "BHD", name: "Bahraini Dinar", symbol: "BD", flag: "🇧🇭", rateToUSD: 0.38),

        // Africa
        CurrencyInfo(code: "ZAR", name: "South African Rand", symbol: "R", flag: "🇿🇦", rateToUSD: 18.63),
        CurrencyInfo(code: "EGP", name: "Egyptian Pound", symbol: "E£", flag: "🇪🇬", rateToUSD: 30.90),
        CurrencyInfo(code: "NGN", name: "Nigerian Naira", symbol: "₦", flag: "🇳🇬", rateToUSD: 900.0),
        CurrencyInfo(code: "KES", name: "Kenyan Shilling", symbol: "KSh", flag: "🇰🇪", rateToUSD: 155.0),
        CurrencyInfo(code: "GHS", name: "Ghanaian Cedi", symbol: "GH₵", flag: "🇬🇭", rateToUSD: 12.50),
        CurrencyInfo(code: "MAD", name: "Moroccan Dirham", symbol: "MAD", flag: "🇲🇦", rateToUSD: 10.05),
    ]

    static func convert(amount: Double, from: CurrencyInfo, to: CurrencyInfo) -> Double {
        // Convert to USD first, then to target currency
        let amountInUSD = amount / from.rateToUSD
        return amountInUSD * to.rateToUSD
    }
}

// MARK: - View Model

@Observable
class CurrencyConverterViewModel {
    var amount: String = "1"
    var fromCurrency: CurrencyInfo
    var toCurrency: CurrencyInfo
    var searchText: String = ""
    var showingFromPicker = false
    var showingToPicker = false

    init() {
        fromCurrency = CurrencyData.all.first(where: { $0.code == "USD" })!
        toCurrency = CurrencyData.all.first(where: { $0.code == "EUR" })!
    }

    var convertedAmount: Double {
        let value = Double(amount) ?? 0
        return CurrencyData.convert(amount: value, from: fromCurrency, to: toCurrency)
    }

    var exchangeRate: Double {
        CurrencyData.convert(amount: 1, from: fromCurrency, to: toCurrency)
    }

    var reverseRate: Double {
        CurrencyData.convert(amount: 1, from: toCurrency, to: fromCurrency)
    }

    var filteredCurrencies: [CurrencyInfo] {
        if searchText.isEmpty { return CurrencyData.all }
        let query = searchText.lowercased()
        return CurrencyData.all.filter {
            $0.code.lowercased().contains(query) ||
            $0.name.lowercased().contains(query)
        }
    }

    func swap() {
        let temp = fromCurrency
        fromCurrency = toCurrency
        toCurrency = temp
    }

    func formatConverted(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 2
        formatter.usesGroupingSeparator = true
        return formatter.string(from: NSNumber(value: value)) ?? String(format: "%.2f", value)
    }

    func formatRate(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = value < 1 ? 6 : 4
        formatter.minimumFractionDigits = 2
        formatter.usesGroupingSeparator = true
        return formatter.string(from: NSNumber(value: value)) ?? String(format: "%.4f", value)
    }

    func digitPressed(_ digit: String) {
        if amount == "0" && digit != "." {
            amount = digit
        } else if digit == "." && amount.contains(".") {
            return
        } else {
            amount += digit
        }
    }

    func deleteDigit() {
        if amount.count > 1 {
            amount.removeLast()
        } else {
            amount = "0"
        }
    }

    func clearAmount() {
        amount = "0"
    }
}

// MARK: - Main View

struct CurrencyConverterView: View {
    @State private var vm = CurrencyConverterViewModel()

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 16) {
                    // From currency card
                    currencyCard(
                        label: "From",
                        currency: vm.fromCurrency,
                        amountText: vm.amount,
                        isEditable: true
                    ) {
                        vm.showingFromPicker = true
                    }

                    // Swap button
                    swapButton

                    // To currency card
                    currencyCard(
                        label: "To",
                        currency: vm.toCurrency,
                        amountText: vm.formatConverted(vm.convertedAmount),
                        isEditable: false
                    ) {
                        vm.showingToPicker = true
                    }

                    // Exchange rate info
                    rateInfo

                    Spacer(minLength: 8)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }

            // Keypad
            converterKeypad
        }
        .sheet(isPresented: $vm.showingFromPicker) {
            CurrencyPickerView(
                selected: $vm.fromCurrency,
                title: "From Currency"
            )
        }
        .sheet(isPresented: $vm.showingToPicker) {
            CurrencyPickerView(
                selected: $vm.toCurrency,
                title: "To Currency"
            )
        }
    }

    // MARK: - Currency Card

    private func currencyCard(
        label: String,
        currency: CurrencyInfo,
        amountText: String,
        isEditable: Bool,
        onTap: @escaping () -> Void
    ) -> some View {
        VStack(spacing: 12) {
            HStack {
                Text(label.uppercased())
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .tracking(1.2)
                Spacer()
            }

            HStack(spacing: 12) {
                // Currency selector
                Button(action: onTap) {
                    HStack(spacing: 8) {
                        Text(currency.flag)
                            .font(.system(size: 28))
                        VStack(alignment: .leading, spacing: 1) {
                            Text(currency.code)
                                .font(.system(size: 16, weight: .bold))
                                .foregroundStyle(.white)
                            Text(currency.name)
                                .font(.system(size: 12))
                                .foregroundStyle(.secondary)
                        }
                        Image(systemName: "chevron.down")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(.plain)

                Spacer()

                // Amount
                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(currency.symbol) \(amountText)")
                        .font(.system(size: 24, weight: .semibold, design: .rounded))
                        .foregroundStyle(isEditable ? .white : .orange)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
            }
        }
        .padding(16)
        .background(Color(white: 0.1))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(isEditable ? Color.orange.opacity(0.3) : Color(white: 0.18), lineWidth: 1)
        )
    }

    // MARK: - Swap Button

    private var swapButton: some View {
        Button(action: { withAnimation(.spring(response: 0.3)) { vm.swap() } }) {
            ZStack {
                Circle()
                    .fill(Color(white: 0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: "arrow.up.arrow.down")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.orange)
            }
        }
        .buttonStyle(.plain)
    }

    // MARK: - Rate Info

    private var rateInfo: some View {
        VStack(spacing: 6) {
            HStack {
                Text("Exchange Rate")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)
                Spacer()
            }
            HStack {
                Text("1 \(vm.fromCurrency.code) = \(vm.formatRate(vm.exchangeRate)) \(vm.toCurrency.code)")
                    .font(.system(size: 15, design: .monospaced))
                    .foregroundStyle(.white)
                Spacer()
            }
            HStack {
                Text("1 \(vm.toCurrency.code) = \(vm.formatRate(vm.reverseRate)) \(vm.fromCurrency.code)")
                    .font(.system(size: 13, design: .monospaced))
                    .foregroundStyle(.secondary)
                Spacer()
            }
        }
        .padding(16)
        .background(Color(white: 0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: - Converter Keypad

    private var converterKeypad: some View {
        let spacing: CGFloat = 10

        return VStack(spacing: spacing) {
            HStack(spacing: spacing) {
                numKey("7", spacing: spacing) { vm.digitPressed("7") }
                numKey("8", spacing: spacing) { vm.digitPressed("8") }
                numKey("9", spacing: spacing) { vm.digitPressed("9") }
            }
            HStack(spacing: spacing) {
                numKey("4", spacing: spacing) { vm.digitPressed("4") }
                numKey("5", spacing: spacing) { vm.digitPressed("5") }
                numKey("6", spacing: spacing) { vm.digitPressed("6") }
            }
            HStack(spacing: spacing) {
                numKey("1", spacing: spacing) { vm.digitPressed("1") }
                numKey("2", spacing: spacing) { vm.digitPressed("2") }
                numKey("3", spacing: spacing) { vm.digitPressed("3") }
            }
            HStack(spacing: spacing) {
                numKey(".", spacing: spacing) { vm.digitPressed(".") }
                numKey("0", spacing: spacing) { vm.digitPressed("0") }
                Button(action: { vm.deleteDigit() }) {
                    Image(systemName: "delete.left")
                        .font(.system(size: 20, weight: .medium))
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(Color(white: 0.15))
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color(white: 0.05))
    }

    private func numKey(_ title: String, spacing: CGFloat, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 22, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(Color(white: 0.15))
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Currency Picker

struct CurrencyPickerView: View {
    @Binding var selected: CurrencyInfo
    let title: String
    @Environment(\.dismiss) private var dismiss
    @State private var searchText = ""

    private var filtered: [CurrencyInfo] {
        if searchText.isEmpty { return CurrencyData.all }
        let q = searchText.lowercased()
        return CurrencyData.all.filter {
            $0.code.lowercased().contains(q) ||
            $0.name.lowercased().contains(q) ||
            $0.symbol.lowercased().contains(q)
        }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { currency in
                Button(action: {
                    selected = currency
                    dismiss()
                }) {
                    HStack(spacing: 12) {
                        Text(currency.flag)
                            .font(.system(size: 28))

                        VStack(alignment: .leading, spacing: 2) {
                            Text(currency.code)
                                .font(.system(size: 16, weight: .bold))
                                .foregroundStyle(.white)
                            Text(currency.name)
                                .font(.system(size: 13))
                                .foregroundStyle(.secondary)
                        }

                        Spacer()

                        Text(currency.symbol)
                            .font(.system(size: 16))
                            .foregroundStyle(.secondary)

                        if currency.code == selected.code {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.orange)
                        }
                    }
                    .padding(.vertical, 4)
                }
                .listRowBackground(
                    currency.code == selected.code
                    ? Color.orange.opacity(0.1)
                    : Color.clear
                )
            }
            .searchable(text: $searchText, prompt: "Search currencies")
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .foregroundStyle(.orange)
                }
            }
        }
    }
}
