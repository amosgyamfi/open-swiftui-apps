//
//  ExpressionParser.swift
//  Opus4point6
//
//  Recursive descent parser for mathematical expressions.
//  Supports: +, -, *, /, ^, !, trig, log, sqrt, variables, constants.
//

import Foundation

// MARK: - Errors

enum ExpressionError: Error, LocalizedError {
    case invalidExpression
    case unknownFunction(String)
    case unknownVariable(String)
    case divisionByZero
    case unexpectedToken(String)
    case unmatchedParenthesis

    var errorDescription: String? {
        switch self {
        case .invalidExpression: return "Invalid expression"
        case .unknownFunction(let name): return "Unknown function: \(name)"
        case .unknownVariable(let name): return "Unknown variable: \(name)"
        case .divisionByZero: return "Division by zero"
        case .unexpectedToken(let token): return "Unexpected: \(token)"
        case .unmatchedParenthesis: return "Unmatched parenthesis"
        }
    }
}

// MARK: - Token

enum Token {
    case number(Double)
    case identifier(String)
    case op(Character)
    case leftParen
    case rightParen
}

// MARK: - Parser

class ExpressionParser {
    var variables: [String: Double] = [:]
    var useDegrees: Bool = false

    private var tokens: [Token] = []
    private var position: Int = 0

    func evaluate(_ expression: String) throws -> Double {
        let cleaned = expression
            .replacingOccurrences(of: "×", with: "*")
            .replacingOccurrences(of: "÷", with: "/")
            .replacingOccurrences(of: "−", with: "-")

        tokens = try tokenize(cleaned)
        position = 0

        guard !tokens.isEmpty else {
            throw ExpressionError.invalidExpression
        }

        let result = try parseExpression()

        if position < tokens.count {
            throw ExpressionError.invalidExpression
        }

        return result
    }

    // MARK: - Tokenizer

    private func tokenize(_ expression: String) throws -> [Token] {
        var rawTokens: [Token] = []
        let chars = Array(expression)
        var i = 0

        while i < chars.count {
            let c = chars[i]

            if c.isWhitespace {
                i += 1
                continue
            }

            // Numbers
            if c.isNumber || (c == "." && i + 1 < chars.count && chars[i + 1].isNumber) {
                var numStr = String(c)
                i += 1
                while i < chars.count && (chars[i].isNumber || chars[i] == ".") {
                    numStr += String(chars[i])
                    i += 1
                }
                // Scientific notation
                if i < chars.count && (chars[i] == "e" || chars[i] == "E") {
                    numStr += String(chars[i])
                    i += 1
                    if i < chars.count && (chars[i] == "+" || chars[i] == "-") {
                        numStr += String(chars[i])
                        i += 1
                    }
                    while i < chars.count && chars[i].isNumber {
                        numStr += String(chars[i])
                        i += 1
                    }
                }
                guard let num = Double(numStr) else {
                    throw ExpressionError.invalidExpression
                }
                rawTokens.append(.number(num))
                continue
            }

            // Identifiers (functions, variables, constants)
            if c.isLetter || c == "_" {
                var ident = String(c)
                i += 1
                while i < chars.count && (chars[i].isLetter || chars[i].isNumber || chars[i] == "_") {
                    ident += String(chars[i])
                    i += 1
                }
                rawTokens.append(.identifier(ident))
                continue
            }

            // π constant
            if c == "π" {
                rawTokens.append(.number(Double.pi))
                i += 1
                continue
            }

            // Parentheses
            if c == "(" {
                rawTokens.append(.leftParen)
                i += 1
                continue
            }
            if c == ")" {
                rawTokens.append(.rightParen)
                i += 1
                continue
            }

            // Operators
            if "+-*/^%!".contains(c) {
                rawTokens.append(.op(c))
                i += 1
                continue
            }

            throw ExpressionError.unexpectedToken(String(c))
        }

        // Insert implicit multiplication
        var result: [Token] = []
        for (idx, token) in rawTokens.enumerated() {
            if idx > 0 {
                let prev = rawTokens[idx - 1]
                if needsImplicitMultiplication(prev, token) {
                    result.append(.op("*"))
                }
            }
            result.append(token)
        }

        return result
    }

    private func needsImplicitMultiplication(_ a: Token, _ b: Token) -> Bool {
        switch (a, b) {
        case (.number, .leftParen): return true      // 2(3) -> 2*(3)
        case (.rightParen, .number): return true      // (3)2 -> (3)*2
        case (.rightParen, .leftParen): return true   // (3)(4) -> (3)*(4)
        case (.rightParen, .identifier): return true  // (3)x -> (3)*x
        case (.number, .identifier):
            // Only if it's NOT followed by ( which would be a function call
            // We handle this in parsePrimary instead
            return false
        default: return false
        }
    }

    // MARK: - Grammar
    // expression = term (('+' | '-') term)*

    private func parseExpression() throws -> Double {
        var result = try parseTerm()

        while position < tokens.count {
            if case .op(let c) = tokens[position], c == "+" || c == "-" {
                position += 1
                let right = try parseTerm()
                result = c == "+" ? result + right : result - right
            } else {
                break
            }
        }
        return result
    }

    // term = power (('*' | '/' | '%') power)*

    private func parseTerm() throws -> Double {
        var result = try parsePower()

        while position < tokens.count {
            if case .op(let c) = tokens[position], c == "*" || c == "/" || c == "%" {
                position += 1
                let right = try parsePower()
                if c == "*" {
                    result *= right
                } else if c == "/" {
                    if right == 0 { throw ExpressionError.divisionByZero }
                    result /= right
                } else {
                    if right == 0 { throw ExpressionError.divisionByZero }
                    result = result.truncatingRemainder(dividingBy: right)
                }
            } else {
                break
            }
        }
        return result
    }

    // power = unary ('^' power)?

    private func parsePower() throws -> Double {
        let base = try parseUnary()

        if position < tokens.count, case .op("^") = tokens[position] {
            position += 1
            let exponent = try parsePower() // right-associative
            return pow(base, exponent)
        }
        return base
    }

    // unary = ('-' | '+') unary | postfix

    private func parseUnary() throws -> Double {
        if position < tokens.count, case .op(let c) = tokens[position], c == "-" || c == "+" {
            position += 1
            let value = try parseUnary()
            return c == "-" ? -value : value
        }
        return try parsePostfix()
    }

    // postfix = primary ('!')?

    private func parsePostfix() throws -> Double {
        var value = try parsePrimary()

        while position < tokens.count, case .op("!") = tokens[position] {
            position += 1
            value = factorial(value)
        }
        return value
    }

    // primary = NUMBER | IDENTIFIER | IDENTIFIER '(' expression ')' | '(' expression ')'

    private func parsePrimary() throws -> Double {
        guard position < tokens.count else {
            throw ExpressionError.invalidExpression
        }

        switch tokens[position] {
        case .number(let value):
            position += 1
            return value

        case .identifier(let name):
            position += 1

            // Function call
            if position < tokens.count, case .leftParen = tokens[position] {
                position += 1
                let arg = try parseExpression()
                guard position < tokens.count, case .rightParen = tokens[position] else {
                    throw ExpressionError.unmatchedParenthesis
                }
                position += 1
                return try applyFunction(name, arg)
            }

            // Constants
            switch name.lowercased() {
            case "pi": return Double.pi
            case "e": return M_E
            case "tau": return Double.pi * 2
            default: break
            }

            // Variables
            if let value = variables[name] {
                return value
            }

            throw ExpressionError.unknownVariable(name)

        case .leftParen:
            position += 1
            let value = try parseExpression()
            guard position < tokens.count, case .rightParen = tokens[position] else {
                throw ExpressionError.unmatchedParenthesis
            }
            position += 1
            return value

        default:
            throw ExpressionError.invalidExpression
        }
    }

    // MARK: - Functions

    private func applyFunction(_ name: String, _ arg: Double) throws -> Double {
        let radArg = useDegrees ? arg * Double.pi / 180.0 : arg

        switch name.lowercased() {
        case "sin": return sin(radArg)
        case "cos": return cos(radArg)
        case "tan": return tan(radArg)
        case "asin", "arcsin":
            let result = asin(arg)
            return useDegrees ? result * 180.0 / Double.pi : result
        case "acos", "arccos":
            let result = acos(arg)
            return useDegrees ? result * 180.0 / Double.pi : result
        case "atan", "arctan":
            let result = atan(arg)
            return useDegrees ? result * 180.0 / Double.pi : result
        case "sinh": return sinh(arg)
        case "cosh": return cosh(arg)
        case "tanh": return tanh(arg)
        case "asinh": return asinh(arg)
        case "acosh": return acosh(arg)
        case "atanh": return atanh(arg)
        case "log", "log10": return log10(arg)
        case "log2": return log2(arg)
        case "ln": return log(arg)
        case "sqrt", "√": return sqrt(arg)
        case "cbrt": return cbrt(arg)
        case "abs": return abs(arg)
        case "ceil": return ceil(arg)
        case "floor": return floor(arg)
        case "round": return round(arg)
        case "exp": return exp(arg)
        default: throw ExpressionError.unknownFunction(name)
        }
    }

    // MARK: - Helpers

    private func factorial(_ n: Double) -> Double {
        if n < 0 { return .nan }
        if n == 0 || n == 1 { return 1 }
        if n != floor(n) { return tgamma(n + 1) } // Gamma function for non-integers
        if n > 170 { return .infinity }
        var result: Double = 1
        for i in 2...Int(n) {
            result *= Double(i)
        }
        return result
    }
}
