//
//  Opus4point6App.swift
//  Opus4point6
//
//  Created by Amos Gyamfi on 6.2.2026.
//

import SwiftUI

@main
struct Opus4point6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
