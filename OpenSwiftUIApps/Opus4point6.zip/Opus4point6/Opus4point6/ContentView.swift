//
//  ContentView.swift
//  Opus4point6
//
//  Created by Amos Gyamfi on 6.2.2026.
//

import SwiftUI

// MARK: - Calculator Mode

enum CalculatorMode: String, CaseIterable, Identifiable {
    case basic = "Basic"
    case scientific = "Scientific"
    case mathNotes = "Math Notes"
    case convert = "Convert"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .basic: return "plus.forwardslash.minus"
        case .scientific: return "function"
        case .mathNotes: return "note.text"
        case .convert: return "arrow.left.arrow.right"
        }
    }
}

// MARK: - Content View

struct ContentView: View {
    @State private var selectedMode: CalculatorMode = .basic

    var body: some View {
        VStack(spacing: 0) {
            // Mode picker
            modePicker
                .padding(.top, 4)

            // Calculator content
            Group {
                switch selectedMode {
                case .basic:
                    BasicCalculatorView()
                case .scientific:
                    ScientificCalculatorView()
                case .mathNotes:
                    MathNotesView()
                case .convert:
                    CurrencyConverterView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .transition(.opacity)
            .animation(.easeInOut(duration: 0.2), value: selectedMode)
        }
        .background(Color.black)
        .preferredColorScheme(.dark)
    }

    // MARK: - Mode Picker

    private var modePicker: some View {
        HStack(spacing: 4) {
            ForEach(CalculatorMode.allCases) { mode in
                Button {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                        selectedMode = mode
                    }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: mode.icon)
                            .font(.system(size: 11, weight: .semibold))
                        Text(mode.rawValue)
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(
                        Capsule()
                            .fill(selectedMode == mode
                                  ? Color.orange
                                  : Color(white: 0.12))
                    )
                    .foregroundStyle(selectedMode == mode ? .white : .secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.bottom, 4)
    }
}

#Preview {
    ContentView()
}
