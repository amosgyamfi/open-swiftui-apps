//
//  MathExpressionParser.swift
//  Composer1Point5
//
//  Evaluates mathematical expressions with variables
//

import Foundation

struct MathExpressionParser {
    static func evaluate(_ expression: String, variables: [String: Double] = [:]) -> Double? {
        simpleEval(expression, vars: variables)
    }
    
    static func simpleEval(_ expr: String, vars: [String: Double]) -> Double? {
        let s = expr.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: " ", with: "")
        guard !s.isEmpty else { return nil }
        return eval(s, vars: vars)
    }
    
    private static func eval(_ s: String, vars: [String: Double]) -> Double? {
        var s = s
        if s.hasPrefix("=") { s = String(s.dropFirst()) }
        
        // + or -
        if let i = lastOperatorIndex(s, ops: ["+", "−", "-"]) {
            let left = String(s[..<s.index(s.startIndex, offsetBy: i)]).trimmingCharacters(in: .whitespaces)
            let opChar = s[s.index(s.startIndex, offsetBy: i)]
            let right = String(s[s.index(s.startIndex, offsetBy: i + 1)...]).trimmingCharacters(in: .whitespaces)
            guard let l = eval(left, vars: vars), let r = eval(right, vars: vars) else { return nil }
            return opChar == "+" ? l + r : l - r
        }
        
        return evalTerm(s, vars: vars)
    }
    
    private static func evalTerm(_ s: String, vars: [String: Double]) -> Double? {
        if let i = lastOperatorIndex(s, ops: ["×", "*", "÷", "/"]) {
            let left = String(s[..<s.index(s.startIndex, offsetBy: i)]).trimmingCharacters(in: .whitespaces)
            let right = String(s[s.index(s.startIndex, offsetBy: i + 1)...]).trimmingCharacters(in: .whitespaces)
            let op = s[s.index(s.startIndex, offsetBy: i)]
            guard let l = evalTerm(left, vars: vars), let r = evalFactor(right, vars: vars) else { return nil }
            if op == "×" || op == "*" { return l * r }
            return r != 0 ? l / r : nil
        }
        return evalFactor(s, vars: vars)
    }
    
    private static func evalFactor(_ s: String, vars: [String: Double]) -> Double? {
        let s = s.trimmingCharacters(in: .whitespaces)
        if s.isEmpty { return nil }
        
        if s.hasPrefix("(") && s.hasSuffix(")") {
            return eval(String(s.dropFirst().dropLast()), vars: vars)
        }
        
        if let i = s.lastIndex(of: "^") {
            let left = String(s[..<i]).trimmingCharacters(in: .whitespaces)
            let right = String(s[s.index(after: i)...]).trimmingCharacters(in: .whitespaces)
            guard let l = evalFactor(left, vars: vars), let r = evalFactor(right, vars: vars) else { return nil }
            return pow(l, r)
        }
        
        if let v = vars[s] { return v }
        if let v = Double(s) { return v }
        
        let fns = ["sqrt", "sin", "cos", "tan", "log", "ln", "abs"]
        for fn in fns {
            if s.hasPrefix("\(fn)(") && s.hasSuffix(")") {
                let inner = String(s.dropFirst(fn.count + 1).dropLast())
                guard let x = eval(inner, vars: vars) else { return nil }
                switch fn {
                case "sqrt": return sqrt(x)
                case "sin": return sin(x * .pi / 180)
                case "cos": return cos(x * .pi / 180)
                case "tan": return tan(x * .pi / 180)
                case "log": return log10(x)
                case "ln": return log(x)
                case "abs": return abs(x)
                default: return nil
                }
            }
        }
        return nil
    }
    
    private static func lastOperatorIndex(_ s: String, ops: [String]) -> Int? {
        var depth = 0
        var lastIdx: Int?
        for (i, c) in s.enumerated() {
            if c == "(" { depth += 1 }
            else if c == ")" { depth -= 1 }
            else if depth == 0 {
                for op in ops {
                    if op.count == 1 && c == Character(op) { lastIdx = i }
                    else if op.count > 1 && s[s.index(s.startIndex, offsetBy: i)...].hasPrefix(op) { lastIdx = i }
                }
            }
        }
        return lastIdx
    }
}
