//
//  CurrencyService.swift
//  Composer1Point5
//
//  Fetches exchange rates from Frankfurter API
//

import Foundation

struct CurrencyRatesResponse: Codable {
    let base: String
    let date: String
    let rates: [String: Double]
}

struct CurrencyInfo: Codable {
    let symbols: [String: String]
}

actor CurrencyService {
    private let baseURL = "https://api.frankfurter.dev"
    private var cachedRates: (base: String, rates: [String: Double], date: Date)?
    private let cacheValidity: TimeInterval = 3600 // 1 hour
    
    func getCurrencies() async throws -> [String: String] {
        let url = URL(string: "\(baseURL)/latest")!
        let (data, _) = try await URLSession.shared.data(from: url)
        let response = try JSONDecoder().decode(CurrencyRatesResponse.self, from: data)
        var symbols: [String: String] = [response.base: fullName(for: response.base)]
        for code in response.rates.keys {
            symbols[code] = fullName(for: code)
        }
        return symbols
    }
    
    func getRates(base: String) async throws -> [String: Double] {
        if let cached = cachedRates, cached.base == base, Date().timeIntervalSince(cached.date) < cacheValidity {
            return cached.rates
        }
        var urlComponents = URLComponents(string: "\(baseURL)/latest")!
        urlComponents.queryItems = [URLQueryItem(name: "base", value: base)]
        let url = urlComponents.url!
        let (data, _) = try await URLSession.shared.data(from: url)
        let response = try JSONDecoder().decode(CurrencyRatesResponse.self, from: data)
        cachedRates = (base, response.rates, Date())
        return response.rates
    }
    
    private func fullName(for code: String) -> String {
        let names: [String: String] = [
            "USD": "US Dollar", "EUR": "Euro", "GBP": "British Pound",
            "JPY": "Japanese Yen", "CHF": "Swiss Franc", "CAD": "Canadian Dollar",
            "AUD": "Australian Dollar", "CNY": "Chinese Yuan", "INR": "Indian Rupee",
            "BRL": "Brazilian Real", "KRW": "South Korean Won", "MXN": "Mexican Peso",
            "RUB": "Russian Ruble", "ZAR": "South African Rand", "HKD": "Hong Kong Dollar",
            "SGD": "Singapore Dollar", "NOK": "Norwegian Krone", "SEK": "Swedish Krona",
            "DKK": "Danish Krone", "PLN": "Polish Złoty", "TRY": "Turkish Lira",
            "THB": "Thai Baht", "IDR": "Indonesian Rupiah", "PHP": "Philippine Peso",
            "CZK": "Czech Koruna", "ILS": "Israeli Shekel", "NZD": "New Zealand Dollar"
        ]
        return names[code] ?? code
    }
}
