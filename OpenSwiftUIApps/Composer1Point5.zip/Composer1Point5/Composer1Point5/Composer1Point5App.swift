//
//  Composer1Point5App.swift
//  Composer1Point5
//
//  Created by Amos Gyamfi on 11.2.2026.
//

import SwiftUI

@main
struct Composer1Point5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
