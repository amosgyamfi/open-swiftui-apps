//
//  ScientificCalculatorView.swift
//  Composer1Point5
//

import SwiftUI

struct ScientificCalculatorView: View {
    @State private var engine = ScientificCalculatorEngine()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Display
                VStack(alignment: .trailing, spacing: 8) {
                    if let op = engine.pendingOperation {
                        Text("\(engine.previousValue.formatted()) \(op.rawValue)")
                            .font(AppTheme.buttonFontSmall)
                            .foregroundStyle(AppTheme.textSecondary)
                    }
                    Text(engine.displayValue)
                        .font(AppTheme.displayFontSmall)
                        .foregroundStyle(AppTheme.textPrimary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.horizontal, 24)
                .padding(.vertical, 24)
                
                // Scientific functions row
                HStack(spacing: 12) {
                    SciButton(title: "sin") { engine.scientificFunction(.sin) }
                    SciButton(title: "cos") { engine.scientificFunction(.cos) }
                    SciButton(title: "tan") { engine.scientificFunction(.tan) }
                    SciButton(title: "ln") { engine.scientificFunction(.ln) }
                    SciButton(title: "log") { engine.scientificFunction(.log) }
                }
                
                HStack(spacing: 12) {
                    SciButton(title: "√") { engine.scientificFunction(.sqrt) }
                    SciButton(title: "x²") { engine.scientificFunction(.square) }
                    SciButton(title: "xʸ") { engine.scientificFunction(.power) }
                    SciButton(title: "π") { engine.scientificFunction(.pi) }
                    SciButton(title: "e") { engine.scientificFunction(.e) }
                }
                .padding(.top, 12)
                
                // Basic keypad
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        CalculatorButton(title: "AC", style: .function) { engine.clear() }
                        CalculatorButton(title: "±", style: .function) { engine.toggleSign() }
                        CalculatorButton(title: "%", style: .function) { engine.percentage() }
                        CalculatorButton(title: "÷", style: .operator) { engine.setOperation(.divide) }
                    }
                    
                    HStack(spacing: 16) {
                        CalculatorButton(title: "7", style: .digit) { engine.inputDigit(7) }
                        CalculatorButton(title: "8", style: .digit) { engine.inputDigit(8) }
                        CalculatorButton(title: "9", style: .digit) { engine.inputDigit(9) }
                        CalculatorButton(title: "×", style: .operator) { engine.setOperation(.multiply) }
                    }
                    
                    HStack(spacing: 16) {
                        CalculatorButton(title: "4", style: .digit) { engine.inputDigit(4) }
                        CalculatorButton(title: "5", style: .digit) { engine.inputDigit(5) }
                        CalculatorButton(title: "6", style: .digit) { engine.inputDigit(6) }
                        CalculatorButton(title: "−", style: .operator) { engine.setOperation(.subtract) }
                    }
                    
                    HStack(spacing: 16) {
                        CalculatorButton(title: "1", style: .digit) { engine.inputDigit(1) }
                        CalculatorButton(title: "2", style: .digit) { engine.inputDigit(2) }
                        CalculatorButton(title: "3", style: .digit) { engine.inputDigit(3) }
                        CalculatorButton(title: "+", style: .operator) { engine.setOperation(.add) }
                    }
                    
                    HStack(spacing: 16) {
                        CalculatorButton(title: "0", style: .digit) { engine.inputDigit(0) }
                            .frame(maxWidth: .infinity)
                        CalculatorButton(title: ".", style: .digit) { engine.inputDecimal() }
                        CalculatorButton(title: "=", style: .operator) { engine.performCalculation() }
                            .frame(width: 160)
                    }
                }
                .padding(16)
                .padding(.top, 16)
            }
        }
    }
}

struct SciButton: View {
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AppTheme.buttonFontSmall)
                .foregroundStyle(AppTheme.accent)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(AppTheme.surface)
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}

@Observable
class ScientificCalculatorEngine: CalculatorEngine {
    enum SciFunction {
        case sin, cos, tan
        case ln, log
        case sqrt, square, power
        case pi, e
    }
    
    var awaitingPowerInput = false
    var powerBase: Double = 0
    var powerExponent: String = ""
    
    override func clear() {
        super.clear()
        awaitingPowerInput = false
        powerExponent = ""
    }
    
    func scientificFunction(_ fn: SciFunction) {
        if fn == .pi { displayValue = "\(Double.pi)"; shouldResetDisplay = true; return }
        if fn == .e { displayValue = "\(M_E)"; shouldResetDisplay = true; return }
        
        guard let value = Double(displayValue) else { return }
        
        var result: Double = 0
        switch fn {
        case .sin: result = sin(value * .pi / 180)
        case .cos: result = cos(value * .pi / 180)
        case .tan: result = tan(value * .pi / 180)
        case .ln: result = log(value)
        case .log: result = log10(value)
        case .sqrt: result = sqrt(value)
        case .square: result = value * value
        case .power:
            powerBase = value
            powerExponent = ""
            awaitingPowerInput = true
            displayValue = "0"
            shouldResetDisplay = true
            return
        case .pi, .e: break
        }
        
        displayValue = formatResult(result)
        shouldResetDisplay = true
    }
    
    override func inputDigit(_ digit: Int) {
        if awaitingPowerInput {
            if powerExponent == "0" && digit != 0 {
                powerExponent = "\(digit)"
            } else {
                powerExponent += "\(digit)"
            }
            if powerExponent.isEmpty { powerExponent = "0" }
            let exp = Double(powerExponent) ?? 0
            displayValue = formatResult(pow(powerBase, exp))
            return
        }
        super.inputDigit(digit)
    }
    
    override func inputDecimal() {
        if awaitingPowerInput { return }
        super.inputDecimal()
    }
    
    override func setOperation(_ operation: CalculatorOperation) {
        if awaitingPowerInput {
            awaitingPowerInput = false
            shouldResetDisplay = true
        }
        super.setOperation(operation)
    }
    
    override func performCalculation() {
        if awaitingPowerInput {
            awaitingPowerInput = false
        }
        super.performCalculation()
    }
    
    private func formatResult(_ value: Double) -> String {
        if value.truncatingRemainder(dividingBy: 1) == 0 && abs(value) < 1e15 {
            return String(format: "%.0f", value)
        }
        return String(format: "%.10g", value)
    }
}

#Preview {
    ScientificCalculatorView()
        .background(AppTheme.background)
}
