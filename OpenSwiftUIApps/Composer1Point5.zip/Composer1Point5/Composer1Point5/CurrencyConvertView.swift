//
//  CurrencyConvertView.swift
//  Composer1Point5
//

import SwiftUI

struct CurrencyConvertView: View {
    @State private var fromCurrency = "USD"
    @State private var toCurrency = "EUR"
    @State private var amount: String = "1"
    @State private var convertedAmount: Double?
    @State private var rates: [String: Double] = [:]
    @State private var currencies: [String: String] = [:]
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    private let majorCurrencies = ["USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "CNY", "INR", "BRL", "KRW", "MXN", "RUB", "ZAR", "HKD", "SGD", "NOK", "SEK", "NZD"]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                if let error = errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundStyle(AppTheme.danger)
                        .padding()
                }
                
                // Amount input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Amount")
                        .font(.headline)
                        .foregroundStyle(AppTheme.textSecondary)
                    HStack {
                        TextField("0", text: $amount)
                            .keyboardType(.decimalPad)
                            .font(.system(size: 32, weight: .light, design: .rounded))
                            .foregroundStyle(AppTheme.textPrimary)
                        Text(fromCurrency)
                            .font(.title2)
                            .foregroundStyle(AppTheme.textSecondary)
                    }
                    .padding()
                    .background(AppTheme.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                
                // Currency selectors
                HStack(spacing: 16) {
                    CurrencyPicker(label: "From", selected: $fromCurrency, currencies: currencies, majors: majorCurrencies)
                    Image(systemName: "arrow.left.arrow.right")
                        .foregroundStyle(AppTheme.accent)
                        .onTapGesture { swapCurrencies() }
                    CurrencyPicker(label: "To", selected: $toCurrency, currencies: currencies, majors: majorCurrencies)
                }
                
                // Convert button
                Button(action: convert) {
                    HStack {
                        if isLoading {
                            ProgressView()
                                .tint(AppTheme.background)
                        } else {
                            Image(systemName: "arrow.triangle.2.circlepath")
                            Text("Convert")
                        }
                    }
                    .font(.headline)
                    .foregroundStyle(AppTheme.background)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(AppTheme.accent)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .disabled(isLoading)
                
                // Result
                if let result = convertedAmount {
                    VStack(spacing: 8) {
                        Text("\(formattedAmount(amount)) \(fromCurrency)")
                            .font(.subheadline)
                            .foregroundStyle(AppTheme.textSecondary)
                        Text("= \(result.formatted(.number.precision(.fractionLength(2)))) \(toCurrency)")
                            .font(.title)
                            .fontWeight(.medium)
                            .foregroundStyle(AppTheme.textPrimary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(24)
                    .background(AppTheme.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
            }
            .padding(24)
        }
        .task {
            await loadRates()
        }
        .onChange(of: fromCurrency) { _, _ in Task { await loadRates() } }
    }
    
    private func formattedAmount(_ s: String) -> String {
        if let d = Double(s) { return d.formatted(.number.precision(.fractionLength(2))) }
        return s
    }
    
    private func swapCurrencies() {
        let t = fromCurrency
        fromCurrency = toCurrency
        toCurrency = t
        convert()
    }
    
    private func convert() {
        guard let amt = Double(amount), amt > 0 else {
            errorMessage = "Enter a valid amount"
            return
        }
        errorMessage = nil
        if fromCurrency == toCurrency {
            convertedAmount = amt
            return
        }
        if let rate = rates[toCurrency] {
            convertedAmount = amt * rate
            return
        }
        Task {
            await loadRates()
            if let rate = rates[toCurrency] {
                await MainActor.run {
                    convertedAmount = amt * rate
                }
            }
        }
    }
    
    private func loadRates() async {
        isLoading = true
        errorMessage = nil
        do {
            let service = CurrencyService()
            let r = try await service.getRates(base: fromCurrency)
            await MainActor.run {
                rates = r
                if currencies.isEmpty {
                    currencies = ["USD": "US Dollar", "EUR": "Euro", "GBP": "British Pound",
                                 "JPY": "Japanese Yen", "CHF": "Swiss Franc", "CAD": "Canadian Dollar",
                                 "AUD": "Australian Dollar", "CNY": "Chinese Yuan", "INR": "Indian Rupee",
                                 "BRL": "Brazilian Real", "KRW": "South Korean Won", "MXN": "Mexican Peso",
                                 "RUB": "Russian Ruble", "ZAR": "South African Rand", "HKD": "Hong Kong Dollar",
                                 "SGD": "Singapore Dollar", "NOK": "Norwegian Krone", "SEK": "Swedish Krona",
                                 "DKK": "Danish Krone", "PLN": "Polish Złoty", "TRY": "Turkish Lira",
                                 "THB": "Thai Baht", "IDR": "Indonesian Rupiah", "NZD": "New Zealand Dollar"]
                }
                if convertedAmount == nil, let amt = Double(amount), amt > 0, fromCurrency != toCurrency {
                    convertedAmount = amt * (r[toCurrency] ?? 1)
                }
            }
        } catch {
            await MainActor.run {
                errorMessage = "Could not load rates. Check connection."
                rates = [:]
            }
        }
        await MainActor.run { isLoading = false }
    }
}

struct CurrencyPicker: View {
    let label: String
    @Binding var selected: String
    let currencies: [String: String]
    let majors: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.caption)
                .foregroundStyle(AppTheme.textSecondary)
            Menu {
                ForEach(majors, id: \.self) { code in
                    Button("\(code) - \(currencies[code] ?? code)") {
                        selected = code
                    }
                }
            } label: {
                HStack {
                    Text(selected)
                        .font(.headline)
                        .foregroundStyle(AppTheme.textPrimary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .foregroundStyle(AppTheme.textSecondary)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(AppTheme.surface)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
        .frame(maxWidth: .infinity)
    }
}

#Preview {
    CurrencyConvertView()
        .background(AppTheme.background)
}
