//
//  ContentView.swift
//  Composer1Point5
//
//  Created by Amos Gyamfi on 11.2.2026.
//

import SwiftUI

struct ContentView: View {
    @State private var selectedMode = 0
    
    var body: some View {
        ZStack(alignment: .top) {
            AppTheme.background
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Mode selector
                HStack(spacing: 0) {
                    ModeButton(title: "Basic", icon: "plus.forwardslash.minus", isSelected: selectedMode == 0) {
                        selectedMode = 0
                    }
                    ModeButton(title: "Scientific", icon: "function", isSelected: selectedMode == 1) {
                        selectedMode = 1
                    }
                    ModeButton(title: "Math Notes", icon: "square.and.pencil", isSelected: selectedMode == 2) {
                        selectedMode = 2
                    }
                    ModeButton(title: "Convert", icon: "arrow.triangle.2.circlepath", isSelected: selectedMode == 3) {
                        selectedMode = 3
                    }
                }
                .padding(.horizontal, 12)
                .padding(.top, 8)
                .padding(.bottom, 12)
                .background(AppTheme.surface.opacity(0.95))
                
                // Content
                TabView(selection: $selectedMode) {
                    BasicCalculatorView()
                        .tag(0)
                    ScientificCalculatorView()
                        .tag(1)
                    MathNotesView()
                        .tag(2)
                    CurrencyConvertView()
                        .tag(3)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut(duration: 0.25), value: selectedMode)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct ModeButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .medium))
                Text(title)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
            }
            .foregroundStyle(isSelected ? AppTheme.accent : AppTheme.textSecondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(
                isSelected ?
                AppTheme.accent.opacity(0.15) :
                Color.clear
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    ContentView()
}
