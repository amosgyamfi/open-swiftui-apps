//
//  MathNotesView.swift
//  Composer1Point5
//
//  Solve expressions, variables, and graph equations
//

import SwiftUI

struct MathNotesView: View {
    @State private var noteText: String = ""
    @State private var variables: [String: Double] = [:]
    @State private var variableName: String = ""
    @State private var variableValue: String = ""
    @State private var showVariableSheet = false
    @State private var graphEquation: String = "x^2"
    @State private var selectedTab = 0
    @State private var evaluationError: String?
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Solver & Variables tab
            solverTab
                .tag(0)
            
            // Graph tab
            graphTab
                .tag(1)
        }
        .tabViewStyle(.page(indexDisplayMode: .automatic))
        .indexViewStyle(.page(backgroundDisplayMode: .always))
        .overlay(alignment: .top) {
            HStack(spacing: 20) {
                Button("Solver") { selectedTab = 0 }
                    .foregroundStyle(selectedTab == 0 ? AppTheme.accent : AppTheme.textSecondary)
                Button("Graph") { selectedTab = 1 }
                    .foregroundStyle(selectedTab == 1 ? AppTheme.accent : AppTheme.textSecondary)
            }
            .padding(.top, 8)
        }
        .sheet(isPresented: $showVariableSheet) {
            variableSheet
        }
    }
    
    private var solverTab: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Expression input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Expression")
                        .font(.headline)
                        .foregroundStyle(AppTheme.textSecondary)
                    TextField("e.g. 2+3*4, sqrt(16), x*2+1", text: $noteText)
                        .textFieldStyle(.plain)
                        .font(.system(.body, design: .monospaced))
                        .padding()
                        .background(AppTheme.surface)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .foregroundStyle(AppTheme.textPrimary)
                        .autocorrectionDisabled()
                    
                    if let err = evaluationError {
                        Text(err)
                            .font(.caption)
                            .foregroundStyle(AppTheme.danger)
                    }
                    
                    Button(action: evaluateExpression) {
                        HStack {
                            Image(systemName: "equal.circle.fill")
                            Text("Calculate")
                        }
                        .font(.headline)
                        .foregroundStyle(AppTheme.background)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(AppTheme.accent)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }
                
                // Variables section
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Variables")
                            .font(.headline)
                            .foregroundStyle(AppTheme.textSecondary)
                        Spacer()
                        Button(action: { showVariableSheet = true }) {
                            Image(systemName: "plus.circle.fill")
                                .foregroundStyle(AppTheme.accent)
                        }
                    }
                    
                    if variables.isEmpty {
                        Text("Add variables like x=10, total=100")
                            .font(.subheadline)
                            .foregroundStyle(AppTheme.textSecondary.opacity(0.8))
                    } else {
                        ForEach(Array(variables.keys.sorted()), id: \.self) { key in
                            HStack {
                                Text("\(key) = \(variables[key]!.formatted())")
                                    .font(.system(.body, design: .monospaced))
                                Spacer()
                                Button(role: .destructive) {
                                    variables.removeValue(forKey: key)
                                } label: {
                                    Image(systemName: "trash")
                                        .font(.caption)
                                }
                            }
                            .padding()
                            .background(AppTheme.surface)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                        }
                    }
                }
            }
            .padding(24)
        }
    }
    
    private var graphTab: some View {
        VStack(spacing: 20) {
            Text("Graph Equation (use x)")
                .font(.headline)
                .foregroundStyle(AppTheme.textSecondary)
            
            TextField("e.g. x^2, 2*x+1, sin(x)", text: $graphEquation)
                .textFieldStyle(.plain)
                .font(.system(.body, design: .monospaced))
                .padding()
                .background(AppTheme.surface)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .foregroundStyle(AppTheme.textPrimary)
                .padding(.horizontal, 24)
            
            EquationGraphView(equation: graphEquation)
                .frame(height: 280)
                .padding(.horizontal, 24)
        }
        .padding(.vertical, 24)
    }
    
    private var variableSheet: some View {
        NavigationStack {
            Form {
                TextField("Variable name (e.g. x)", text: $variableName)
                    .autocorrectionDisabled()
                TextField("Value", text: $variableValue)
                    .keyboardType(.decimalPad)
            }
            .scrollContentBackground(.hidden)
            .background(AppTheme.background)
            .navigationTitle("Add Variable")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showVariableSheet = false }
                        .foregroundStyle(AppTheme.accent)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        if !variableName.isEmpty, let val = Double(variableValue) {
                            variables[variableName] = val
                            variableName = ""
                            variableValue = ""
                            showVariableSheet = false
                        }
                    }
                    .foregroundStyle(AppTheme.accent)
                }
            }
        }
    }
    
    private func evaluateExpression() {
        evaluationError = nil
        let expr: String
        if let eqIndex = noteText.firstIndex(of: "=") {
            expr = String(noteText[..<eqIndex]).trimmingCharacters(in: .whitespaces)
        } else {
            expr = noteText.trimmingCharacters(in: .whitespaces)
        }
        let result = MathExpressionParser.simpleEval(expr, vars: variables)
        if let r = result {
            noteText = "\(expr) = \(r.formatted())"
        } else {
            evaluationError = "Could not evaluate expression"
        }
    }
}

struct EquationGraphView: View {
    let equation: String
    
    private let range: ClosedRange<Double> = -5...5
    private let steps = 200
    
    var body: some View {
        GeometryReader { geo in
            let path = graphPath(in: geo.size)
            ZStack {
                // Grid
                gridPath(in: geo.size)
                    .stroke(AppTheme.surfaceElevated, lineWidth: 1)
                
                // Axes
                axesPath(in: geo.size)
                    .stroke(AppTheme.textSecondary.opacity(0.5), lineWidth: 1)
                
                // Curve
                path
                    .stroke(AppTheme.accent, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
            }
        }
        .background(AppTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    
    private func graphPath(in size: CGSize) -> Path {
        var path = Path()
        let width = size.width
        let height = size.height
        let midX = width / 2
        let midY = height / 2
        let scaleX = width / (range.upperBound - range.lowerBound)
        let scaleY = height / (range.upperBound - range.lowerBound) * 0.4
        
        var started = false
        for i in 0...steps {
            let x = range.lowerBound + (range.upperBound - range.lowerBound) * Double(i) / Double(steps)
            let vars = ["x": x]
            guard let y = MathExpressionParser.simpleEval(equation, vars: vars),
                  y.isFinite, abs(y) < 1e6 else {
                started = false
                continue
            }
            let px = midX + CGFloat(x) * scaleX
            let py = midY - CGFloat(y) * scaleY
            let point = CGPoint(x: px, y: py)
            if point.y >= -50 && point.y <= height + 50 {
                if started {
                    path.addLine(to: point)
                } else {
                    path.move(to: point)
                    started = true
                }
            } else {
                started = false
            }
        }
        return path
    }
    
    private func gridPath(in size: CGSize) -> Path {
        var path = Path()
        let w = size.width
        let h = size.height
        for i in stride(from: 0, through: w, by: w/10) {
            path.move(to: CGPoint(x: i, y: 0))
            path.addLine(to: CGPoint(x: i, y: h))
        }
        for i in stride(from: 0, through: h, by: h/10) {
            path.move(to: CGPoint(x: 0, y: i))
            path.addLine(to: CGPoint(x: w, y: i))
        }
        return path
    }
    
    private func axesPath(in size: CGSize) -> Path {
        var path = Path()
        let midX = size.width / 2
        let midY = size.height / 2
        path.move(to: CGPoint(x: 0, y: midY))
        path.addLine(to: CGPoint(x: size.width, y: midY))
        path.move(to: CGPoint(x: midX, y: 0))
        path.addLine(to: CGPoint(x: midX, y: size.height))
        return path
    }
}

#Preview {
    MathNotesView()
        .background(AppTheme.background)
}
