//
//  Theme.swift
//  Composer1Point5
//
//  Design system for the calculator app
//

import SwiftUI

enum AppTheme {
    // Colors - Warm dark theme with amber accents
    static let background = Color(red: 0.08, green: 0.08, blue: 0.12)
    static let surface = Color(red: 0.12, green: 0.12, blue: 0.18)
    static let surfaceElevated = Color(red: 0.16, green: 0.16, blue: 0.22)
    static let accent = Color(red: 1.0, green: 0.72, blue: 0.2)
    static let accentSecondary = Color(red: 0.35, green: 0.65, blue: 0.95)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.7)
    static let operatorColor = Color(red: 0.4, green: 0.8, blue: 0.6)
    static let danger = Color(red: 0.95, green: 0.4, blue: 0.4)
    
    // Typography
    static let displayFont = Font.system(size: 48, weight: .light, design: .rounded)
    static let displayFontSmall = Font.system(size: 32, weight: .light, design: .rounded)
    static let buttonFont = Font.system(size: 24, weight: .medium, design: .rounded)
    static let buttonFontSmall = Font.system(size: 18, weight: .medium, design: .rounded)
}
