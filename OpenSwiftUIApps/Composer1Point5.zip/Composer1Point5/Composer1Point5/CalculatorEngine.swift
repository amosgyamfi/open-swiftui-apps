//
//  CalculatorEngine.swift
//  Composer1Point5
//
//  Shared calculation logic for Basic and Scientific calculators
//

import Foundation

enum CalculatorOperation: String {
    case add = "+"
    case subtract = "−"
    case multiply = "×"
    case divide = "÷"
}

@Observable
class CalculatorEngine {
    var displayValue: String = "0"
    var previousValue: Double = 0
    var pendingOperation: CalculatorOperation?
    var shouldResetDisplay: Bool = false
    var isScientificMode: Bool = false
    
    func inputDigit(_ digit: Int) {
        if shouldResetDisplay {
            displayValue = "\(digit)"
            shouldResetDisplay = false
        } else if displayValue == "0" && digit != 0 {
            displayValue = "\(digit)"
        } else if displayValue != "0" {
            displayValue += "\(digit)"
        }
    }
    
    func inputDecimal() {
        if shouldResetDisplay {
            displayValue = "0."
            shouldResetDisplay = false
        } else if !displayValue.contains(".") {
            displayValue += "."
        }
    }
    
    func setOperation(_ operation: CalculatorOperation) {
        if let value = Double(displayValue) {
            if pendingOperation != nil {
                performCalculation()
            }
            previousValue = value
            pendingOperation = operation
            shouldResetDisplay = true
        }
    }
    
    func performCalculation() {
        guard let operation = pendingOperation,
              let currentValue = Double(displayValue) else { return }
        
        var result: Double = 0
        switch operation {
        case .add: result = previousValue + currentValue
        case .subtract: result = previousValue - currentValue
        case .multiply: result = previousValue * currentValue
        case .divide: result = currentValue != 0 ? previousValue / currentValue : 0
        }
        
        displayValue = formatResult(result)
        pendingOperation = nil
        previousValue = result
        shouldResetDisplay = true
    }
    
    func clear() {
        displayValue = "0"
        previousValue = 0
        pendingOperation = nil
        shouldResetDisplay = false
    }
    
    func toggleSign() {
        if let value = Double(displayValue), value != 0 {
            displayValue = formatResult(-value)
        }
    }
    
    func percentage() {
        if let value = Double(displayValue) {
            displayValue = formatResult(value / 100)
            shouldResetDisplay = true
        }
    }
    
    private func formatResult(_ value: Double) -> String {
        if value.truncatingRemainder(dividingBy: 1) == 0 && abs(value) < 1e15 {
            return String(format: "%.0f", value)
        }
        let formatted = String(format: "%.10g", value)
        return formatted
    }
}
