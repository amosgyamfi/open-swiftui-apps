//
//  BasicCalculatorView.swift
//  Composer1Point5
//

import SwiftUI

struct BasicCalculatorView: View {
    @State private var engine = CalculatorEngine()
    
    var body: some View {
        VStack(spacing: 0) {
            // Display
            VStack(alignment: .trailing, spacing: 8) {
                if let op = engine.pendingOperation {
                    Text("\(engine.previousValue.formatted()) \(op.rawValue)")
                        .font(AppTheme.buttonFontSmall)
                        .foregroundStyle(AppTheme.textSecondary)
                }
                Text(engine.displayValue)
                    .font(AppTheme.displayFont)
                    .foregroundStyle(AppTheme.textPrimary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding(.horizontal, 24)
            .padding(.vertical, 32)
            
            // Keypad
            VStack(spacing: 16) {
                // Row 1: AC, +/-, %, ÷
                HStack(spacing: 16) {
                    CalculatorButton(title: "AC", style: .function) { engine.clear() }
                    CalculatorButton(title: "±", style: .function) { engine.toggleSign() }
                    CalculatorButton(title: "%", style: .function) { engine.percentage() }
                    CalculatorButton(title: "÷", style: .operator) { engine.setOperation(.divide) }
                }
                
                // Row 2: 7, 8, 9, ×
                HStack(spacing: 16) {
                    CalculatorButton(title: "7", style: .digit) { engine.inputDigit(7) }
                    CalculatorButton(title: "8", style: .digit) { engine.inputDigit(8) }
                    CalculatorButton(title: "9", style: .digit) { engine.inputDigit(9) }
                    CalculatorButton(title: "×", style: .operator) { engine.setOperation(.multiply) }
                }
                
                // Row 3: 4, 5, 6, −
                HStack(spacing: 16) {
                    CalculatorButton(title: "4", style: .digit) { engine.inputDigit(4) }
                    CalculatorButton(title: "5", style: .digit) { engine.inputDigit(5) }
                    CalculatorButton(title: "6", style: .digit) { engine.inputDigit(6) }
                    CalculatorButton(title: "−", style: .operator) { engine.setOperation(.subtract) }
                }
                
                // Row 4: 1, 2, 3, +
                HStack(spacing: 16) {
                    CalculatorButton(title: "1", style: .digit) { engine.inputDigit(1) }
                    CalculatorButton(title: "2", style: .digit) { engine.inputDigit(2) }
                    CalculatorButton(title: "3", style: .digit) { engine.inputDigit(3) }
                    CalculatorButton(title: "+", style: .operator) { engine.setOperation(.add) }
                }
                
                // Row 5: 0, ., =
                HStack(spacing: 16) {
                    CalculatorButton(
                        title: "0",
                        style: .digit,
                        action: { engine.inputDigit(0) }
                    )
                    .frame(maxWidth: .infinity)
                    
                    CalculatorButton(
                        title: ".",
                        style: .digit,
                        action: { engine.inputDecimal() }
                    )
                    
                    CalculatorButton(
                        title: "=",
                        style: .operator,
                        action: { engine.performCalculation() }
                    )
                    .frame(width: 160)
                }
            }
            .padding(16)
        }
    }
}

struct CalculatorButton: View {
    let title: String
    let style: ButtonStyle
    let action: () -> Void
    
    enum ButtonStyle {
        case digit
        case `operator`
        case function
    }
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AppTheme.buttonFont)
                .foregroundStyle(foregroundColor)
                .frame(maxWidth: .infinity)
                .frame(height: 72)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
    }
    
    private var foregroundColor: Color {
        switch style {
        case .digit: return AppTheme.textPrimary
        case .operator: return AppTheme.operatorColor
        case .function: return AppTheme.textSecondary
        }
    }
    
    private var backgroundColor: Color {
        switch style {
        case .digit: return AppTheme.surface
        case .operator: return AppTheme.surfaceElevated
        case .function: return AppTheme.surface
        }
    }
}

#Preview {
    BasicCalculatorView()
        .background(AppTheme.background)
}
