import SwiftUI

enum CalculatorMode: String, CaseIterable, Identifiable {
    case basic = "Basic"
    case scientific = "Scientific"
    case mathNotes = "Math Notes"
    case convert = "Convert"

    var id: String { rawValue }
}

struct ContentView: View {
    @StateObject private var calculatorEngine = CalculatorEngine()
    @StateObject private var mathNotesEngine = MathNotesEngine()
    @StateObject private var currencyConverter = CurrencyConverter()

    @State private var selectedMode: CalculatorMode = .basic

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.08, green: 0.14, blue: 0.28),
                    Color(red: 0.10, green: 0.26, blue: 0.44),
                    Color(red: 0.20, green: 0.40, blue: 0.45)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.cyan.opacity(0.20))
                .frame(width: 280)
                .blur(radius: 30)
                .offset(x: -140, y: -360)

            Circle()
                .fill(Color.orange.opacity(0.20))
                .frame(width: 260)
                .blur(radius: 38)
                .offset(x: 160, y: 300)

            VStack(spacing: 14) {
                header
                modePicker

                Group {
                    switch selectedMode {
                    case .basic:
                        BasicCalculatorView(engine: calculatorEngine)
                    case .scientific:
                        ScientificCalculatorView(engine: calculatorEngine)
                    case .mathNotes:
                        MathNotesModeView(engine: mathNotesEngine)
                    case .convert:
                        ConvertModeView(converter: currencyConverter)
                    }
                }
                .frame(maxWidth: 760, maxHeight: .infinity, alignment: .top)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
        }
        .task {
            await currencyConverter.refreshRates()
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Calc Studio")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("Basic, scientific, math notes, and conversion")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
            }
            Spacer()
        }
    }

    private var modePicker: some View {
        Picker("Mode", selection: $selectedMode) {
            ForEach(CalculatorMode.allCases) { mode in
                Text(mode.rawValue).tag(mode)
            }
        }
        .pickerStyle(.segmented)
        .padding(10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct BasicCalculatorView: View {
    @ObservedObject var engine: CalculatorEngine

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 4)

    var body: some View {
        VStack(spacing: 14) {
            CalculatorDisplay(value: engine.display, subtitle: "Basic")

            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(basicButtons) { button in
                    Button(button.title) {
                        perform(button.title)
                    }
                    .buttonStyle(CalculatorPadStyle(kind: button.kind))
                    .gridCellColumns(button.columns)
                }
            }
        }
        .calculatorPanelStyle()
    }

    private var basicButtons: [PadButtonSpec] {
        [
            PadButtonSpec(title: "AC", kind: .utility),
            PadButtonSpec(title: "±", kind: .utility),
            PadButtonSpec(title: "%", kind: .utility),
            PadButtonSpec(title: "÷", kind: .operation),
            PadButtonSpec(title: "7", kind: .digit),
            PadButtonSpec(title: "8", kind: .digit),
            PadButtonSpec(title: "9", kind: .digit),
            PadButtonSpec(title: "×", kind: .operation),
            PadButtonSpec(title: "4", kind: .digit),
            PadButtonSpec(title: "5", kind: .digit),
            PadButtonSpec(title: "6", kind: .digit),
            PadButtonSpec(title: "−", kind: .operation),
            PadButtonSpec(title: "1", kind: .digit),
            PadButtonSpec(title: "2", kind: .digit),
            PadButtonSpec(title: "3", kind: .digit),
            PadButtonSpec(title: "+", kind: .operation),
            PadButtonSpec(title: "0", kind: .digit, columns: 2),
            PadButtonSpec(title: ".", kind: .digit),
            PadButtonSpec(title: "=", kind: .equals)
        ]
    }

    private func perform(_ title: String) {
        switch title {
        case "0"..."9":
            engine.inputDigit(title)
        case ".":
            engine.inputDecimal()
        case "AC":
            engine.clearAll()
        case "±":
            engine.toggleSign()
        case "%":
            engine.percent()
        case "÷":
            engine.setOperation(.divide)
        case "×":
            engine.setOperation(.multiply)
        case "−":
            engine.setOperation(.subtract)
        case "+":
            engine.setOperation(.add)
        case "=":
            engine.equals()
        default:
            break
        }
    }
}

private struct ScientificCalculatorView: View {
    @ObservedObject var engine: CalculatorEngine

    private let functionColumns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 5)
    private let keypadColumns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 4)

    var body: some View {
        VStack(spacing: 14) {
            CalculatorDisplay(
                value: engine.display,
                subtitle: engine.isRadiansMode ? "Scientific · RAD" : "Scientific · DEG"
            )

            LazyVGrid(columns: functionColumns, spacing: 10) {
                ForEach(scientificFunctions) { button in
                    Button(button.title) {
                        performScientific(button.title)
                    }
                    .buttonStyle(CalculatorPadStyle(kind: .science))
                }
            }

            LazyVGrid(columns: keypadColumns, spacing: 12) {
                ForEach(keypadButtons) { button in
                    Button(button.title) {
                        performKeypad(button.title)
                    }
                    .buttonStyle(CalculatorPadStyle(kind: button.kind))
                    .gridCellColumns(button.columns)
                }
            }
        }
        .calculatorPanelStyle()
    }

    private var scientificFunctions: [PadButtonSpec] {
        [
            PadButtonSpec(title: "sin", kind: .science),
            PadButtonSpec(title: "cos", kind: .science),
            PadButtonSpec(title: "tan", kind: .science),
            PadButtonSpec(title: "asin", kind: .science),
            PadButtonSpec(title: "acos", kind: .science),
            PadButtonSpec(title: "atan", kind: .science),
            PadButtonSpec(title: "ln", kind: .science),
            PadButtonSpec(title: "log", kind: .science),
            PadButtonSpec(title: "√x", kind: .science),
            PadButtonSpec(title: "x²", kind: .science),
            PadButtonSpec(title: "xʸ", kind: .science),
            PadButtonSpec(title: "1/x", kind: .science),
            PadButtonSpec(title: "|x|", kind: .science),
            PadButtonSpec(title: "π", kind: .science),
            PadButtonSpec(title: "e", kind: .science),
            PadButtonSpec(title: "!", kind: .science),
            PadButtonSpec(title: "RAD/DEG", kind: .science)
        ]
    }

    private var keypadButtons: [PadButtonSpec] {
        [
            PadButtonSpec(title: "AC", kind: .utility),
            PadButtonSpec(title: "±", kind: .utility),
            PadButtonSpec(title: "%", kind: .utility),
            PadButtonSpec(title: "÷", kind: .operation),
            PadButtonSpec(title: "7", kind: .digit),
            PadButtonSpec(title: "8", kind: .digit),
            PadButtonSpec(title: "9", kind: .digit),
            PadButtonSpec(title: "×", kind: .operation),
            PadButtonSpec(title: "4", kind: .digit),
            PadButtonSpec(title: "5", kind: .digit),
            PadButtonSpec(title: "6", kind: .digit),
            PadButtonSpec(title: "−", kind: .operation),
            PadButtonSpec(title: "1", kind: .digit),
            PadButtonSpec(title: "2", kind: .digit),
            PadButtonSpec(title: "3", kind: .digit),
            PadButtonSpec(title: "+", kind: .operation),
            PadButtonSpec(title: "0", kind: .digit, columns: 2),
            PadButtonSpec(title: ".", kind: .digit),
            PadButtonSpec(title: "=", kind: .equals)
        ]
    }

    private func performKeypad(_ title: String) {
        switch title {
        case "0"..."9":
            engine.inputDigit(title)
        case ".":
            engine.inputDecimal()
        case "AC":
            engine.clearAll()
        case "±":
            engine.toggleSign()
        case "%":
            engine.percent()
        case "÷":
            engine.setOperation(.divide)
        case "×":
            engine.setOperation(.multiply)
        case "−":
            engine.setOperation(.subtract)
        case "+":
            engine.setOperation(.add)
        case "=":
            engine.equals()
        default:
            break
        }
    }

    private func performScientific(_ title: String) {
        switch title {
        case "sin":
            engine.applyTrig(.sin)
        case "cos":
            engine.applyTrig(.cos)
        case "tan":
            engine.applyTrig(.tan)
        case "asin":
            engine.applyInverseTrig(.sin)
        case "acos":
            engine.applyInverseTrig(.cos)
        case "atan":
            engine.applyInverseTrig(.tan)
        case "ln":
            engine.applyUnary(Foundation.log)
        case "log":
            engine.applyUnary(Foundation.log10)
        case "√x":
            engine.applyUnary(Foundation.sqrt)
        case "x²":
            engine.square()
        case "xʸ":
            engine.setOperation(.power)
        case "1/x":
            engine.reciprocal()
        case "|x|":
            engine.applyUnary(Foundation.fabs)
        case "π":
            engine.insertConstant(.pi)
        case "e":
            engine.insertConstant(M_E)
        case "!":
            engine.factorial()
        case "RAD/DEG":
            engine.toggleAngleMode()
        default:
            break
        }
    }
}

private struct MathNotesModeView: View {
    @ObservedObject var engine: MathNotesEngine

    @State private var statement: String = ""
    @State private var graphExpression: String = "sin(x)"
    @State private var graphPoints: [GraphPoint] = []
    @State private var graphStatus: String = "Tap Plot to render"

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                inputSection
                outputSection
                variablesSection
                graphSection
                historySection
            }
            .padding(.bottom, 8)
        }
        .calculatorPanelStyle()
        .onAppear {
            if graphPoints.isEmpty {
                plotGraph()
            }
        }
    }

    private var inputSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Expression")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            TextField("Examples: a = 12/4, sin(pi/2), a*9", text: $statement, axis: .vertical)
                .lineLimit(2...5)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(12)
                .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)

            HStack(spacing: 10) {
                Button("Evaluate") {
                    engine.evaluateStatement(statement)
                }
                .buttonStyle(ActionCapsuleStyle(background: .blue))

                Button("Clear History") {
                    engine.clearHistory()
                }
                .buttonStyle(ActionCapsuleStyle(background: .indigo))
            }
        }
    }

    private var outputSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Result")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            Text(engine.output)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(12)
                .background(Color.cyan.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)
        }
    }

    private var variablesSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Variables")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            if engine.variables.isEmpty {
                Text("No variables yet. Assign with: x = 42")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.70))
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(engine.variables.keys.sorted(), id: \.self) { key in
                            let value = engine.variables[key] ?? 0
                            Text("\(key) = \(CalculatorEngine.format(value))")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 7)
                                .background(Color.white.opacity(0.14), in: Capsule())
                                .foregroundStyle(.white)
                        }
                    }
                }
            }
        }
    }

    private var graphSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Graph Equation (y = f(x))")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            HStack(spacing: 10) {
                TextField("sin(x) + a", text: $graphExpression)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(10)
                    .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.white)

                Button("Plot") {
                    plotGraph()
                }
                .buttonStyle(ActionCapsuleStyle(background: .mint))
            }

            GraphCanvasView(points: graphPoints)
                .frame(height: 210)

            Text(graphStatus)
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.78))
        }
    }

    private var historySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("History")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            if engine.history.isEmpty {
                Text("No calculations yet")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.70))
            } else {
                VStack(spacing: 7) {
                    ForEach(engine.history.prefix(8)) { item in
                        HStack {
                            Text(item.statement)
                                .lineLimit(1)
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.82))

                            Spacer(minLength: 8)

                            Text(item.result)
                                .lineLimit(1)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                        }
                        .padding(10)
                        .background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
        }
    }

    private func plotGraph() {
        let expression = graphExpression.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !expression.isEmpty else {
            graphStatus = "Enter an expression to graph"
            graphPoints = []
            return
        }

        let xMin = -10.0
        let xMax = 10.0
        let steps = 360

        var samples: [GraphPoint] = []
        samples.reserveCapacity(steps + 1)

        for step in 0...steps {
            let t = Double(step) / Double(steps)
            let x = xMin + (xMax - xMin) * t

            if let y = try? engine.evaluateExpression(expression, extraVariables: ["x": x]), y.isFinite {
                samples.append(GraphPoint(x: x, y: y))
            }
        }

        guard samples.count > 1 else {
            graphStatus = "Unable to graph this expression"
            graphPoints = []
            return
        }

        graphPoints = samples
        graphStatus = "Showing y = \(expression)"
    }
}

private struct ConvertModeView: View {
    @ObservedObject var converter: CurrencyConverter

    @State private var amountText: String = "1.00"
    @State private var fromCode: String = "USD"
    @State private var toCode: String = "EUR"

    private var availableCurrencies: [Currency] {
        let codes = Set(converter.rates.keys)
        let filtered = Currency.majorCurrencies.filter { codes.contains($0.code) }
        return filtered.isEmpty ? Currency.majorCurrencies : filtered
    }

    private var convertedText: String {
        let amount = parseAmount(amountText)
        guard let value = converter.convert(amount: amount, from: fromCode, to: toCode) else {
            return "Unavailable"
        }
        return CalculatorEngine.format(value)
    }

    var body: some View {
        VStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Amount")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))

                TextField("Enter amount", text: $amountText)
                    .keyboardType(.decimalPad)
                    .padding(12)
                    .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(.white)
            }

            VStack(spacing: 10) {
                currencyPicker(title: "From", selection: $fromCode)

                HStack {
                    Spacer()
                    Button {
                        swap(&fromCode, &toCode)
                    } label: {
                        Image(systemName: "arrow.up.arrow.down")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(11)
                            .background(Color.indigo.opacity(0.75), in: Capsule())
                    }
                    Spacer()
                }

                currencyPicker(title: "To", selection: $toCode)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Converted")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))

                HStack {
                    Text(convertedText)
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Spacer()
                    Text(toCode)
                        .font(.system(size: 16, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white.opacity(0.88))
                }
                .padding(12)
                .background(Color.teal.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
            }

            statusBlock

            HStack(spacing: 10) {
                Button("Refresh Rates") {
                    Task {
                        await converter.refreshRates()
                        ensureSupportedSelections()
                    }
                }
                .buttonStyle(ActionCapsuleStyle(background: .mint))

                Spacer()
            }
        }
        .calculatorPanelStyle()
        .onAppear {
            ensureSupportedSelections()
        }
        .onChange(of: converter.rates.keys.sorted()) { _, _ in
            ensureSupportedSelections()
        }
    }

    private var statusBlock: some View {
        VStack(alignment: .leading, spacing: 4) {
            if converter.isLoading {
                Text("Updating live exchange rates...")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.78))
            }

            if let error = converter.errorMessage {
                Text(error)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.yellow)
            }

            if let updated = converter.lastUpdated {
                Text("Last updated: \(updated.formatted(date: .abbreviated, time: .shortened))")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.78))
            } else {
                Text("Using fallback USD-based rates")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.78))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func currencyPicker(title: String, selection: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))

            Picker(title, selection: selection) {
                ForEach(availableCurrencies) { currency in
                    Text("\(currency.code) · \(currency.name)").tag(currency.code)
                }
            }
            .pickerStyle(.menu)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            .tint(.white)
        }
    }

    private func parseAmount(_ text: String) -> Double {
        let sanitized = text.replacingOccurrences(of: ",", with: ".")
        return Double(sanitized) ?? 0
    }

    private func ensureSupportedSelections() {
        let codes = Set(availableCurrencies.map(\.code))

        if !codes.contains(fromCode) {
            fromCode = codes.contains("USD") ? "USD" : (availableCurrencies.first?.code ?? "USD")
        }

        if !codes.contains(toCode) || toCode == fromCode {
            toCode = codes.contains("EUR") && fromCode != "EUR"
                ? "EUR"
                : (availableCurrencies.first(where: { $0.code != fromCode })?.code ?? fromCode)
        }
    }
}

private struct GraphPoint {
    let x: Double
    let y: Double
}

private struct GraphCanvasView: View {
    let points: [GraphPoint]

    private let xRange: ClosedRange<Double> = -10...10

    private var yRange: ClosedRange<Double> {
        guard !points.isEmpty else { return -10...10 }

        let minValue = points.map(\.y).min() ?? -1
        let maxValue = points.map(\.y).max() ?? 1

        if minValue == maxValue {
            return (minValue - 1)...(maxValue + 1)
        }

        let padding = (maxValue - minValue) * 0.15
        let lower = max(minValue - padding, -100)
        let upper = min(maxValue + padding, 100)
        return lower...upper
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14)
                .fill(Color.white.opacity(0.08))

            if points.count < 2 {
                Text("No graph")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.60))
            } else {
                GeometryReader { proxy in
                    let size = proxy.size

                    Canvas { context, _ in
                        drawGrid(in: &context, size: size)
                        drawAxes(in: &context, size: size)
                        drawCurve(in: &context, size: size)
                    }
                }
            }
        }
    }

    private func drawGrid(in context: inout GraphicsContext, size: CGSize) {
        var path = Path()

        for i in 1..<5 {
            let x = size.width * CGFloat(i) / 5
            path.move(to: CGPoint(x: x, y: 0))
            path.addLine(to: CGPoint(x: x, y: size.height))
        }

        for i in 1..<5 {
            let y = size.height * CGFloat(i) / 5
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: size.width, y: y))
        }

        context.stroke(path, with: .color(.white.opacity(0.12)), lineWidth: 1)
    }

    private func drawAxes(in context: inout GraphicsContext, size: CGSize) {
        guard xRange.contains(0), yRange.contains(0) else { return }

        let origin = map(x: 0, y: 0, size: size)

        var xAxis = Path()
        xAxis.move(to: CGPoint(x: 0, y: origin.y))
        xAxis.addLine(to: CGPoint(x: size.width, y: origin.y))

        var yAxis = Path()
        yAxis.move(to: CGPoint(x: origin.x, y: 0))
        yAxis.addLine(to: CGPoint(x: origin.x, y: size.height))

        context.stroke(xAxis, with: .color(.white.opacity(0.45)), lineWidth: 1.2)
        context.stroke(yAxis, with: .color(.white.opacity(0.45)), lineWidth: 1.2)
    }

    private func drawCurve(in context: inout GraphicsContext, size: CGSize) {
        var path = Path()
        var previousPoint: CGPoint?

        for sample in points {
            let point = map(x: sample.x, y: sample.y, size: size)

            if let previous = previousPoint, abs(previous.y - point.y) > size.height * 0.72 {
                path.move(to: point)
            } else if previousPoint == nil {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }

            previousPoint = point
        }

        context.stroke(path, with: .color(.mint), lineWidth: 2)
    }

    private func map(x: Double, y: Double, size: CGSize) -> CGPoint {
        let xProgress = (x - xRange.lowerBound) / (xRange.upperBound - xRange.lowerBound)
        let yProgress = (y - yRange.lowerBound) / (yRange.upperBound - yRange.lowerBound)

        let mappedX = size.width * CGFloat(xProgress)
        let mappedY = size.height * (1 - CGFloat(yProgress))
        return CGPoint(x: mappedX, y: mappedY)
    }
}

private struct CalculatorDisplay: View {
    let value: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .trailing, spacing: 6) {
            Text(subtitle)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.75))

            Text(value)
                .font(.system(size: 54, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.40)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .foregroundStyle(.white)
        }
        .padding(14)
        .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 18))
    }
}

private struct PadButtonSpec: Identifiable {
    let id = UUID()
    let title: String
    let kind: PadButtonKind
    let columns: Int

    init(title: String, kind: PadButtonKind, columns: Int = 1) {
        self.title = title
        self.kind = kind
        self.columns = columns
    }
}

private enum PadButtonKind {
    case digit
    case utility
    case operation
    case equals
    case science
}

private struct CalculatorPadStyle: ButtonStyle {
    let kind: PadButtonKind

    func makeBody(configuration: Configuration) -> some View {
        let baseColor: Color

        switch kind {
        case .digit:
            baseColor = Color.white.opacity(0.15)
        case .utility:
            baseColor = Color.gray.opacity(0.55)
        case .operation:
            baseColor = Color.orange.opacity(0.84)
        case .equals:
            baseColor = Color.teal.opacity(0.90)
        case .science:
            baseColor = Color.indigo.opacity(0.70)
        }

        return configuration.label
            .font(.system(size: 22, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(baseColor, in: RoundedRectangle(cornerRadius: 16))
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.easeOut(duration: 0.14), value: configuration.isPressed)
    }
}

private struct ActionCapsuleStyle: ButtonStyle {
    let background: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(background.opacity(configuration.isPressed ? 0.70 : 0.95), in: Capsule())
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

private extension View {
    func calculatorPanelStyle() -> some View {
        self
            .padding(14)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.white.opacity(0.15), lineWidth: 1)
            )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
