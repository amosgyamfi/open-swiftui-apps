//
//  Codex5point3App.swift
//  Codex5point3
//
//  Created by Amos Gyamfi on 6.2.2026.
//

import SwiftUI

@main
struct Codex5point3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
