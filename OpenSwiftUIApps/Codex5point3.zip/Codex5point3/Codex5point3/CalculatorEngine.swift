import Foundation
import SwiftUI
import Combine

final class CalculatorEngine: ObservableObject {
    enum BinaryOperation {
        case add
        case subtract
        case multiply
        case divide
        case power
    }

    @Published var display: String = "0"
    @Published var isRadiansMode: Bool = true

    private var accumulator: Double?
    private var pendingOperation: BinaryOperation?
    private var isTyping: Bool = false

    func inputDigit(_ digit: String) {
        guard display.count < 18 else { return }

        if isTyping {
            display = display == "0" ? digit : display + digit
        } else {
            display = digit
            isTyping = true
        }
    }

    func inputDecimal() {
        if isTyping {
            guard !display.contains(".") else { return }
            display += "."
        } else {
            display = "0."
            isTyping = true
        }
    }

    func clearAll() {
        display = "0"
        accumulator = nil
        pendingOperation = nil
        isTyping = false
    }

    func toggleSign() {
        let value = currentValue() * -1
        display = Self.format(value)
    }

    func percent() {
        let value = currentValue() / 100
        display = Self.format(value)
        isTyping = false
    }

    func reciprocal() {
        let value = currentValue()
        guard value != 0 else {
            display = "Error"
            isTyping = false
            return
        }
        display = Self.format(1 / value)
        isTyping = false
    }

    func square() {
        let value = currentValue()
        display = Self.format(value * value)
        isTyping = false
    }

    func setOperation(_ operation: BinaryOperation) {
        let value = currentValue()

        if let pending = pendingOperation, let acc = accumulator, isTyping {
            let result = apply(pending, lhs: acc, rhs: value)
            accumulator = result
            display = Self.format(result)
        } else if accumulator == nil {
            accumulator = value
        }

        pendingOperation = operation
        isTyping = false
    }

    func equals() {
        guard let pending = pendingOperation, let acc = accumulator else { return }

        let rhs = currentValue()
        let result = apply(pending, lhs: acc, rhs: rhs)

        display = Self.format(result)
        accumulator = nil
        pendingOperation = nil
        isTyping = false
    }

    func applyUnary(_ operation: (Double) -> Double) {
        let result = operation(currentValue())
        display = Self.format(result)
        isTyping = false
    }

    func applyTrig(_ kind: TrigKind) {
        let input = currentValue()
        let radians = isRadiansMode ? input : input * .pi / 180

        let output: Double
        switch kind {
        case .sin:
            output = Foundation.sin(radians)
        case .cos:
            output = Foundation.cos(radians)
        case .tan:
            output = Foundation.tan(radians)
        }

        display = Self.format(output)
        isTyping = false
    }

    func applyInverseTrig(_ kind: TrigKind) {
        let input = currentValue()

        let radians: Double
        switch kind {
        case .sin:
            radians = Foundation.asin(input)
        case .cos:
            radians = Foundation.acos(input)
        case .tan:
            radians = Foundation.atan(input)
        }

        let output = isRadiansMode ? radians : radians * 180 / .pi
        display = Self.format(output)
        isTyping = false
    }

    func insertConstant(_ value: Double) {
        display = Self.format(value)
        isTyping = false
    }

    func factorial() {
        let value = currentValue()
        guard value >= 0, value.rounded() == value, value <= 170 else {
            display = "Error"
            isTyping = false
            return
        }

        let n = Int(value)
        if n == 0 {
            display = "1"
            isTyping = false
            return
        }

        let result = (1...n).map(Double.init).reduce(1, *)
        display = Self.format(result)
        isTyping = false
    }

    func toggleAngleMode() {
        isRadiansMode.toggle()
    }

    private func currentValue() -> Double {
        Double(display) ?? 0
    }

    private func apply(_ operation: BinaryOperation, lhs: Double, rhs: Double) -> Double {
        switch operation {
        case .add:
            lhs + rhs
        case .subtract:
            lhs - rhs
        case .multiply:
            lhs * rhs
        case .divide:
            rhs == 0 ? .nan : lhs / rhs
        case .power:
            Foundation.pow(lhs, rhs)
        }
    }

    static func format(_ value: Double) -> String {
        guard value.isFinite else { return "Error" }

        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 12
        formatter.minimumFractionDigits = 0
        formatter.usesGroupingSeparator = false
        formatter.locale = Locale(identifier: "en_US_POSIX")

        return formatter.string(from: NSNumber(value: value)) ?? String(value)
    }
}

enum TrigKind {
    case sin
    case cos
    case tan
}

struct MathHistoryItem: Identifiable {
    let id = UUID()
    let statement: String
    let result: String
    let timestamp: Date
}

@MainActor
final class MathNotesEngine: ObservableObject {
    @Published var variables: [String: Double] = [:]
    @Published var history: [MathHistoryItem] = []
    @Published var output: String = "Enter a math expression or assignment"

    func evaluateStatement(_ text: String) {
        let statement = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !statement.isEmpty else { return }

        do {
            let evaluation = try MathExpressionEvaluator.evaluateStatement(statement, variables: &variables)
            let formatted = CalculatorEngine.format(evaluation.value)

            if let assigned = evaluation.assignedVariable {
                output = "\(assigned) = \(formatted)"
            } else {
                output = formatted
            }

            history.insert(
                MathHistoryItem(statement: statement, result: output, timestamp: Date()),
                at: 0
            )

            if history.count > 30 {
                history = Array(history.prefix(30))
            }
        } catch {
            output = error.localizedDescription
        }
    }

    func evaluateExpression(_ expression: String, extraVariables: [String: Double] = [:]) throws -> Double {
        try MathExpressionEvaluator.evaluateExpression(expression, variables: mergedVariables(extraVariables))
    }

    func clearHistory() {
        history.removeAll()
    }

    private func mergedVariables(_ extra: [String: Double]) -> [String: Double] {
        variables.merging(extra) { _, new in new }
    }
}

struct MathEvaluation {
    let value: Double
    let assignedVariable: String?
}

enum MathExpressionError: LocalizedError {
    case invalidToken(String)
    case unexpectedEnd
    case expected(String)
    case unknownIdentifier(String)
    case invalidAssignment
    case divisionByZero

    var errorDescription: String? {
        switch self {
        case .invalidToken(let token):
            "Invalid token: \(token)"
        case .unexpectedEnd:
            "Unexpected end of expression"
        case .expected(let item):
            "Expected \(item)"
        case .unknownIdentifier(let name):
            "Unknown identifier: \(name)"
        case .invalidAssignment:
            "Invalid assignment. Use format: variable = expression"
        case .divisionByZero:
            "Division by zero"
        }
    }
}

enum MathExpressionEvaluator {
    static func evaluateStatement(_ statement: String, variables: inout [String: Double]) throws -> MathEvaluation {
        if let assignment = splitAssignment(statement) {
            let name = assignment.name
            guard isValidIdentifier(name) else {
                throw MathExpressionError.invalidAssignment
            }

            let value = try evaluateExpression(assignment.expression, variables: variables)
            variables[name] = value
            return MathEvaluation(value: value, assignedVariable: name)
        }

        return MathEvaluation(
            value: try evaluateExpression(statement, variables: variables),
            assignedVariable: nil
        )
    }

    static func evaluateExpression(_ expression: String, variables: [String: Double]) throws -> Double {
        var parser = ExpressionParser(tokens: try tokenize(expression), variables: variables)
        let value = try parser.parseExpression()

        guard parser.isAtEnd else {
            throw MathExpressionError.expected("end of expression")
        }

        if !value.isFinite {
            throw MathExpressionError.invalidToken("non-finite result")
        }

        return value
    }

    private static func splitAssignment(_ statement: String) -> (name: String, expression: String)? {
        guard let range = statement.range(of: "=") else { return nil }

        let name = statement[..<range.lowerBound].trimmingCharacters(in: .whitespacesAndNewlines)
        let expression = statement[range.upperBound...].trimmingCharacters(in: .whitespacesAndNewlines)

        guard !name.isEmpty, !expression.isEmpty else { return nil }
        return (name, expression)
    }

    private static func isValidIdentifier(_ name: String) -> Bool {
        let pattern = "^[A-Za-z_][A-Za-z0-9_]*$"
        return name.range(of: pattern, options: .regularExpression) != nil
    }

    private enum Token: Equatable {
        case number(Double)
        case identifier(String)
        case plus
        case minus
        case multiply
        case divide
        case power
        case leftParen
        case rightParen
        case comma
    }

    private static func tokenize(_ input: String) throws -> [Token] {
        var tokens: [Token] = []
        let chars = Array(input)
        var i = 0

        while i < chars.count {
            let char = chars[i]

            if char.isWhitespace {
                i += 1
                continue
            }

            if char.isNumber || char == "." {
                let start = i
                var hasDecimal = (char == ".")
                i += 1

                while i < chars.count {
                    let c = chars[i]
                    if c.isNumber {
                        i += 1
                    } else if c == "." && !hasDecimal {
                        hasDecimal = true
                        i += 1
                    } else {
                        break
                    }
                }

                let text = String(chars[start..<i])
                guard let value = Double(text) else {
                    throw MathExpressionError.invalidToken(text)
                }
                tokens.append(.number(value))
                continue
            }

            if char.isLetter || char == "_" {
                let start = i
                i += 1

                while i < chars.count && (chars[i].isLetter || chars[i].isNumber || chars[i] == "_") {
                    i += 1
                }

                let identifier = String(chars[start..<i])
                tokens.append(.identifier(identifier))
                continue
            }

            switch char {
            case "+": tokens.append(.plus)
            case "-": tokens.append(.minus)
            case "*": tokens.append(.multiply)
            case "/": tokens.append(.divide)
            case "^": tokens.append(.power)
            case "(": tokens.append(.leftParen)
            case ")": tokens.append(.rightParen)
            case ",": tokens.append(.comma)
            default:
                throw MathExpressionError.invalidToken(String(char))
            }

            i += 1
        }

        return tokens
    }

    private struct ExpressionParser {
        let tokens: [Token]
        let variables: [String: Double]
        var index: Int = 0

        var isAtEnd: Bool {
            index >= tokens.count
        }

        mutating func parseExpression() throws -> Double {
            try parseAddSubtract()
        }

        mutating private func parseAddSubtract() throws -> Double {
            var value = try parseMultiplyDivide()

            while let token = peek() {
                switch token {
                case .plus:
                    _ = advance()
                    value += try parseMultiplyDivide()
                case .minus:
                    _ = advance()
                    value -= try parseMultiplyDivide()
                default:
                    return value
                }
            }

            return value
        }

        mutating private func parseMultiplyDivide() throws -> Double {
            var value = try parsePower()

            while let token = peek() {
                switch token {
                case .multiply:
                    _ = advance()
                    value *= try parsePower()
                case .divide:
                    _ = advance()
                    let divisor = try parsePower()
                    guard divisor != 0 else { throw MathExpressionError.divisionByZero }
                    value /= divisor
                default:
                    return value
                }
            }

            return value
        }

        mutating private func parsePower() throws -> Double {
            var value = try parseUnary()

            if match(.power) {
                let rhs = try parsePower()
                value = Foundation.pow(value, rhs)
            }

            return value
        }

        mutating private func parseUnary() throws -> Double {
            if match(.plus) {
                return try parseUnary()
            }

            if match(.minus) {
                return -(try parseUnary())
            }

            return try parsePrimary()
        }

        mutating private func parsePrimary() throws -> Double {
            guard let token = advance() else {
                throw MathExpressionError.unexpectedEnd
            }

            switch token {
            case .number(let value):
                return value

            case .identifier(let name):
                if match(.leftParen) {
                    let args = try parseArguments()
                    return try evaluateFunction(name: name, args: args)
                }

                if let constant = constantValue(for: name) {
                    return constant
                }

                guard let value = variables[name] else {
                    throw MathExpressionError.unknownIdentifier(name)
                }
                return value

            case .leftParen:
                let value = try parseExpression()
                guard match(.rightParen) else {
                    throw MathExpressionError.expected("')'")
                }
                return value

            default:
                throw MathExpressionError.invalidToken("\(token)")
            }
        }

        mutating private func parseArguments() throws -> [Double] {
            var args: [Double] = []

            if match(.rightParen) {
                return args
            }

            while true {
                args.append(try parseExpression())

                if match(.rightParen) {
                    return args
                }

                guard match(.comma) else {
                    throw MathExpressionError.expected("',' or ')' in function arguments")
                }
            }
        }

        private func evaluateFunction(name: String, args: [Double]) throws -> Double {
            switch name.lowercased() {
            case "sin":
                return try unary(name, args, Foundation.sin)
            case "cos":
                return try unary(name, args, Foundation.cos)
            case "tan":
                return try unary(name, args, Foundation.tan)
            case "asin":
                return try unary(name, args, Foundation.asin)
            case "acos":
                return try unary(name, args, Foundation.acos)
            case "atan":
                return try unary(name, args, Foundation.atan)
            case "sqrt":
                return try unary(name, args, Foundation.sqrt)
            case "log":
                return try unary(name, args, Foundation.log10)
            case "ln":
                return try unary(name, args, Foundation.log)
            case "abs":
                return try unary(name, args, Foundation.fabs)
            case "exp":
                return try unary(name, args, Foundation.exp)
            case "floor":
                return try unary(name, args, Foundation.floor)
            case "ceil":
                return try unary(name, args, Foundation.ceil)
            case "pow":
                guard args.count == 2 else { throw MathExpressionError.expected("pow(base, exponent)") }
                return Foundation.pow(args[0], args[1])
            case "min":
                guard args.count == 2 else { throw MathExpressionError.expected("min(a, b)") }
                return Swift.min(args[0], args[1])
            case "max":
                guard args.count == 2 else { throw MathExpressionError.expected("max(a, b)") }
                return Swift.max(args[0], args[1])
            default:
                throw MathExpressionError.unknownIdentifier(name)
            }
        }

        private func unary(_ name: String, _ args: [Double], _ f: (Double) -> Double) throws -> Double {
            guard args.count == 1 else {
                throw MathExpressionError.expected("\(name)(x)")
            }
            return f(args[0])
        }

        private func constantValue(for identifier: String) -> Double? {
            switch identifier.lowercased() {
            case "pi":
                return .pi
            case "e":
                return M_E
            default:
                return nil
            }
        }

        private func peek() -> Token? {
            guard index < tokens.count else { return nil }
            return tokens[index]
        }

        @discardableResult
        mutating private func advance() -> Token? {
            guard index < tokens.count else { return nil }
            defer { index += 1 }
            return tokens[index]
        }

        mutating private func match(_ expected: Token) -> Bool {
            guard let token = peek(), token == expected else { return false }
            _ = advance()
            return true
        }
    }
}

struct Currency: Identifiable, Hashable {
    let id: String
    let code: String
    let name: String
    let symbol: String

    init(code: String, name: String, symbol: String) {
        self.id = code
        self.code = code
        self.name = name
        self.symbol = symbol
    }

    static let majorCurrencies: [Currency] = [
        Currency(code: "USD", name: "US Dollar", symbol: "$"),
        Currency(code: "EUR", name: "Euro", symbol: "€"),
        Currency(code: "GBP", name: "British Pound", symbol: "£"),
        Currency(code: "JPY", name: "Japanese Yen", symbol: "¥"),
        Currency(code: "CNY", name: "Chinese Yuan", symbol: "¥"),
        Currency(code: "AUD", name: "Australian Dollar", symbol: "A$"),
        Currency(code: "CAD", name: "Canadian Dollar", symbol: "C$"),
        Currency(code: "CHF", name: "Swiss Franc", symbol: "CHF"),
        Currency(code: "HKD", name: "Hong Kong Dollar", symbol: "HK$"),
        Currency(code: "NZD", name: "New Zealand Dollar", symbol: "NZ$"),
        Currency(code: "SEK", name: "Swedish Krona", symbol: "kr"),
        Currency(code: "KRW", name: "South Korean Won", symbol: "₩"),
        Currency(code: "SGD", name: "Singapore Dollar", symbol: "S$"),
        Currency(code: "NOK", name: "Norwegian Krone", symbol: "kr"),
        Currency(code: "MXN", name: "Mexican Peso", symbol: "$"),
        Currency(code: "INR", name: "Indian Rupee", symbol: "₹"),
        Currency(code: "RUB", name: "Russian Ruble", symbol: "₽"),
        Currency(code: "ZAR", name: "South African Rand", symbol: "R"),
        Currency(code: "TRY", name: "Turkish Lira", symbol: "₺"),
        Currency(code: "BRL", name: "Brazilian Real", symbol: "R$"),
        Currency(code: "TWD", name: "New Taiwan Dollar", symbol: "NT$"),
        Currency(code: "DKK", name: "Danish Krone", symbol: "kr"),
        Currency(code: "PLN", name: "Polish Zloty", symbol: "zl"),
        Currency(code: "THB", name: "Thai Baht", symbol: "฿"),
        Currency(code: "IDR", name: "Indonesian Rupiah", symbol: "Rp"),
        Currency(code: "HUF", name: "Hungarian Forint", symbol: "Ft"),
        Currency(code: "CZK", name: "Czech Koruna", symbol: "Kc"),
        Currency(code: "ILS", name: "Israeli New Shekel", symbol: "₪"),
        Currency(code: "CLP", name: "Chilean Peso", symbol: "$"),
        Currency(code: "PHP", name: "Philippine Peso", symbol: "₱"),
        Currency(code: "AED", name: "UAE Dirham", symbol: "د.إ"),
        Currency(code: "COP", name: "Colombian Peso", symbol: "$"),
        Currency(code: "SAR", name: "Saudi Riyal", symbol: "﷼"),
        Currency(code: "MYR", name: "Malaysian Ringgit", symbol: "RM"),
        Currency(code: "RON", name: "Romanian Leu", symbol: "lei")
    ]

    static let fallbackRatesUSDBase: [String: Double] = [
        "USD": 1.0,
        "EUR": 0.92,
        "GBP": 0.79,
        "JPY": 149.8,
        "CNY": 7.18,
        "AUD": 1.53,
        "CAD": 1.36,
        "CHF": 0.88,
        "HKD": 7.82,
        "NZD": 1.67,
        "SEK": 10.5,
        "KRW": 1358,
        "SGD": 1.35,
        "NOK": 10.7,
        "MXN": 17.2,
        "INR": 83.2,
        "RUB": 90.4,
        "ZAR": 18.8,
        "TRY": 31.1,
        "BRL": 4.96,
        "TWD": 31.5,
        "DKK": 6.86,
        "PLN": 3.98,
        "THB": 35.6,
        "IDR": 15750,
        "HUF": 361,
        "CZK": 23.4,
        "ILS": 3.66,
        "CLP": 950,
        "PHP": 56.2,
        "AED": 3.67,
        "COP": 3920,
        "SAR": 3.75,
        "MYR": 4.71,
        "RON": 4.58
    ]
}

@MainActor
final class CurrencyConverter: ObservableObject {
    @Published private(set) var rates: [String: Double] = Currency.fallbackRatesUSDBase
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var isLoading: Bool = false
    @Published var errorMessage: String?

    func convert(amount: Double, from: String, to: String) -> Double? {
        guard let fromRate = rates[from], let toRate = rates[to], fromRate != 0 else { return nil }
        let usdAmount = amount / fromRate
        return usdAmount * toRate
    }

    func refreshRates() async {
        isLoading = true
        defer { isLoading = false }

        do {
            let url = URL(string: "https://open.er-api.com/v6/latest/USD")!
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(ExchangeRatesResponse.self, from: data)

            guard response.result.lowercased() == "success" else {
                throw URLError(.badServerResponse)
            }

            var filtered: [String: Double] = [:]
            for currency in Currency.majorCurrencies {
                if let rate = response.rates[currency.code] {
                    filtered[currency.code] = rate
                }
            }

            if filtered["USD"] == nil {
                filtered["USD"] = 1
            }

            rates = filtered
            lastUpdated = Date()
            errorMessage = nil
        } catch {
            errorMessage = "Live rates unavailable. Using offline rates."
        }
    }

    struct ExchangeRatesResponse: Decodable {
        let result: String
        let rates: [String: Double]
    }
}
